"""Fixed reviewed CPU operations only; no commands, callbacks or runtime installs."""
import contextlib
import hashlib
import importlib
from importlib import metadata
import json
import os
from pathlib import Path
import socket
import sys

ROOT=Path(__file__).resolve().parent
CURRENT=None

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

class Failure(Exception):
    def __init__(self,code,message):super().__init__(message);self.code=code

def pairs(values):
    result={}
    for key,value in values:
        if key in result:raise Failure('invalid_arguments','Duplicate JSON key: '+key)
        result[key]=value
    return result

def nonfinite(value):raise Failure('invalid_arguments','Nonfinite JSON constant: '+value)
def no_network(*args,**kwargs):raise Failure('execution_error','Scientific networking is disabled')

def main():
    global CURRENT
    assert os.environ['CUDA_VISIBLE_DEVICES']=='' and os.environ['NVIDIA_VISIBLE_DEVICES']=='none'
    assert os.environ['PROJ_NETWORK']=='OFF'
    for key in ['MPLCONFIGDIR','NUMBA_CACHE_DIR','XDG_CACHE_HOME']:
        assert Path(os.environ[key]).resolve().is_relative_to(ROOT)
    config=json.loads((ROOT/'workers.json').read_text(encoding='utf-8'))
    assert len(sys.argv)==2 and sys.argv[1] in config['operations']
    name=sys.argv[1];cfg=config['operations'][name];CURRENT=cfg
    assert Path(sys.executable).absolute()==Path(cfg['python']).absolute()
    assert Path(sys.prefix).absolute()==Path(cfg['python']).parent.parent.absolute()
    assert sha(__file__)==config['entrypoint_sha256']
    for path,wanted in cfg['files_sha256'].items():
        if not Path(path).is_file():raise Failure('missing_dependency','Missing pinned CPU file: '+path)
        if sha(path)!=wanted:raise Failure('integrity_error','Pinned CPU file changed: '+path)
    raw=sys.stdin.buffer.read(4_000_001)
    if len(raw)>4_000_000:raise Failure('resource_limit','Argument byte bound exceeded')
    try:args=json.loads(raw,object_pairs_hook=pairs,parse_constant=nonfinite)
    except (ValueError,UnicodeError) as exc:raise Failure('invalid_arguments',str(exc)) from exc
    if not isinstance(args,dict):raise Failure('invalid_arguments','Arguments must be a JSON object')
    installed={}
    for requirement in cfg['requirements']:
        package,wanted=requirement.split('==')
        try:actual=metadata.version(package)
        except metadata.PackageNotFoundError as exc:raise Failure('missing_dependency',str(exc)) from exc
        if actual!=wanted:raise Failure('missing_dependency',package+' expected '+wanted+'; found '+actual)
        installed[package]=actual
    inputs={}
    for field in cfg['path_fields']:
        path=Path(args[field])
        if not path.is_absolute() or path.is_symlink():raise Failure('invalid_path','Expected an immutable workspace snapshot')
        if not path.is_file():raise Failure('missing_input','Input file does not exist')
        inputs[str(path)]=sha(path)
    socket.socket.connect=no_network;socket.create_connection=no_network
    sys.path.insert(0,cfg['source_root'])
    with contextlib.redirect_stdout(sys.stderr):
        module,function=cfg['source_callable'].split(':')
        result=getattr(importlib.import_module(module),function)(args=args)
    assert inputs=={path:sha(path) for path in inputs}
    proof=result['provenance']
    assert proof['tool']==name and proof['implementation_sha256']==cfg['implementation_sha256']
    for package,actual in installed.items():assert proof['installed_versions'][package]==actual
    assert not result['artifacts'] and not proof['output_sha256']
    proof['binary_sha256']=sha(cfg['kernel_path'])
    proof['build_receipt_sha256']=sha(cfg['build_receipt'])
    assert proof['binary_sha256']==cfg['kernel_sha256']
    assert proof['build_receipt_sha256']==cfg['build_receipt_sha256']
    proof['kernel_artifact_kind']=cfg['kernel_artifact_kind']
    sys.stdout.write(json.dumps({'status':'ok','tool':name,'data':result},allow_nan=False)+'\n')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        cfg=CURRENT or {};declared=cfg.get('error_codes',[])
        # Preserve every explicit error code. Unknown codes remain fail-closed at the host bridge.
        # Untyped assertions/protocol/source failures are invalid_result, not fabricated upstream failures.
        code=getattr(exc,'code','invalid_result')
        sys.stdout.write(json.dumps({'status':'error','tool':sys.argv[1] if len(sys.argv)>1 else '',
            'error':{'code':code,'message':str(exc) or type(exc).__name__,'retryable':False}},allow_nan=False)+'\n')
        raise SystemExit(3)
