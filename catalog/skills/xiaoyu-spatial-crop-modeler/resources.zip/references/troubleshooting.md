# Spatial Crop Modeler — Troubleshooting

This file collects diagnostic detail for failures of `ag-cube-cm` runs.
Sections:

- [Manual datacube fixes](#manual-datacube-fixes) — workarounds when the
  aggeodata auto-builder fails. Most users should reach for the
  `geospatial-cube-processor` skill **first** — its `stack_datasets`
  function uses a pure xarray + rioxarray path with configurable
  `target_resolution` and `resampling_method` and avoids every issue
  documented below. The fixes here are only needed when you want to keep
  using the aggeodata internal stacker.
- [DSSAT rc=99 diagnosis](#dssat-returned-rc99--diagnose-in-this-order)
- [Other failure modes](#other-failure-modes)

---

## Manual datacube fixes

The `ag-cube-cm` auto-builder is robust for typical small-area runs but a few
failure modes show up at country scale or with mixed-resolution sources. If
you hit one of these between Step 5 and Step 6, fix the intermediate cube then
re-run `ag-cube-cm` in `with_cubes` mode.

**Boundary NaN after `xr.interp`** — when the reference grid extends slightly
beyond the source grid, `xr.interp` returns NaN on edge pixels (`bounds_error=False`
only suppresses scipy errors; the NaNs come from the linear interpolant having no
neighbors). Fill with the nearest valid value along both axes:

```python
resampled = da.interp(y=ref_y, x=ref_x, method="linear")
resampled = resampled.ffill("y").bfill("y").ffill("x").bfill("x")
```

**Stacker signal-abort on large file counts (SIGABRT or SIGSEGV)** — at ~800+
input files per variable the rasterio warp path can hit heap corruption and the
process dies with SIGABRT or SIGSEGV (signal type varies by allocator version;
~1000 is *not* a reliable threshold). Bypass it with a pure-xarray stack.

CHIRPS and CHIRTS daily files require two extra fixes:
1. Every file stores `date=0` (integer zero) instead of the real date.
2. Slightly different float y-coordinates across files cause `join='outer'` (the
   `open_mfdataset` default) to union all y values, silently doubling the grid
   (e.g. 35 → 70 rows for a Honduras bbox). Fix: `join='override'`.

```python
import os, re
import xarray as xr
import rioxarray  # registers the .rio accessor
from datetime import datetime

def stack_daily_files(file_paths: list) -> xr.Dataset:
    """Stack many daily NetCDF/GeoTIFF files; handles CHIRPS/CHIRTS quirks."""
    file_paths = sorted(file_paths)       # chronological by filename
    ds = xr.open_mfdataset(
        file_paths,
        combine="by_coords",
        join="override",   # prevents float y-coord union from doubling y dim
        parallel=True,
    )
    # CHIRPS/CHIRTS: every file has date=0 — rebuild from YYYY.MM.DD in filename
    if ds.time.dtype.kind != "M":
        dates = []
        for f in file_paths:
            m = re.search(r'(\d{4})[.\-_](\d{2})[.\-_](\d{2})', os.path.basename(f))
            if m:
                dates.append(datetime(int(m.group(1)), int(m.group(2)), int(m.group(3))))
        if dates:
            ds = ds.assign_coords(time=dates)
    ds = ds.rio.write_crs("EPSG:4326")    # mfdataset drops CRS metadata — re-attach
    return ds
```

The `join="override"` line is the critical one: omitting it silently doubles the
grid. The `write_crs` call is mandatory — without it downstream tools see
`ds.rio.crs == None` and silently misalign.

**Multiple grid-mapping variables after merging climate sources** — after
combining CHIRPS, CHIRTS, and AgERA5 datasets with `xr.merge`, each source
carries its own `spatial_ref` or `crs` variable. `rioxarray` raises
`RioXarrayError: Multiple grid mappings exist` on the merged dataset. Drop the
duplicates before writing:

```python
# Drop duplicate spatial_ref / crs variables kept by xr.merge
for v in list(merged.data_vars):
    if v in ("spatial_ref", "crs"):
        merged = merged.drop_vars(v)
# Strip grid_mapping attributes so rioxarray picks no mapping at all
for v in list(merged.data_vars):
    merged[v].attrs.pop("grid_mapping", None)
merged.to_netcdf(out_path, engine="netcdf4")
```

**Time coordinate is all zeros after manual stack** — when input files lack CF
time metadata, the time index is zero-valued and slices wrong silently. Rebuild:

```python
assert ds.time.dtype.kind == "M", "time coord is not datetime — reassign via cftime_range"

ds = ds.assign_coords(
    time=xr.cftime_range("2021-01-01", periods=ds.sizes["time"], freq="D")
              .to_datetimeindex()
)
```

For monthly cubes use `freq="MS"`, annual `freq="YS"`.

---

## `DSSAT returned rc=99` — diagnose in this order

`rc=99` is DSSAT's generic "something went wrong" exit code. The accompanying
message ("Crop code incompatible") is often misleading — the real cause can be
any of the four below. Work through them from cheapest to most expensive; most
rc=99 cases are caught in the first two.

0. **Truncated `SMODEL` in the X-file** — check this first when **every** pixel
   fails. Open `WARNING.OUT` in the pixel working directory: if it says
   `Crop: BN; Model: RGRO 048` or `Crop: MZ; Model: ZCER 048`, the model code
   has lost its first character. DSSAT reads `SMODEL` by fixed column (71, the
   one its own header announces), so one character of drift in the X-file writer
   breaks every run regardless of crop, cultivar, soil or weather.
   **Test:**
   ```python
   lines = open(xfile).read().splitlines()
   i = next(i for i, l in enumerate(lines) if l.startswith("@N GENERAL"))
   col = lines[i].index("SMODEL")
   print(repr(lines[i + 1][col:]))   # must read CRGRO / MZCER / CSCER ..., not RGRO / ZCER
   ```
   Fixed in ag-cube-cm by padding `SNAME` to its full 25 characters and keeping
   the separator space before `SMODEL`. If you see it, your ag-cube-cm predates
   that fix — reinstall from `main`.
1. **Empty weather DataFrame** — the pixel had NaN weather (common at grid
   edges where the climate cube doesn't cover the soil cube extent). DSSAT
   reads zero rows and bails out.
   **Test:** `df_wth.dropna()` returns 0 rows. Expected at the edges; suspicious
   in the interior — check climate-cube extent vs soil-cube extent.
2. **Working path contains a space** — DSSATPRO's whitespace-delimited parser
   corrupts the M-line and reports a fake "crop code incompatible".
   **Test:** `print(working_path)`. If it contains a space (`OneDrive - CGIAR`,
   `Program Files`, …), move to a space-free path like `D:/dssat_work` or
   `/tmp/dssat_runs`.
3. **Wrong cultivar module** — e.g. WHCER cultivars (`IB1487`) under the
   bundled WHAPS048 binary, or a maize cultivar passed to a wheat run.
   **Test:** open the generated X-file, check the `SMODEL` line matches the
   cultivar's expected module (`WHAPS048` for wheat WHAPS, `MZCER048` for maize,
   `CRGRO048` for legumes). For wheat, use `IB1015`, `IB0001`, `IB0002`, or
   `IB1500`.
4. **DSSAT binary missing or not on PATH** — `dssat_path` in config is wrong,
   or DSSAT isn't installed.
   **Test:** `which dscsm048` (Linux/Mac) or check the binary at the configured
   `dssat_path`/`bin_path`.

---

## Other failure modes

| Symptom | Cause | Fix |
|---------|-------|-----|
| All pixels skipped | Grid edges have NaN from coarser AgERA5/SoilGrids | Expected — increase `max_pixels` or check interior pixels |
| Soil/climate grid mismatch — resolution or CRS differ | SoilGrids (~0.002°) is ~25× finer than CHIRPS (0.05°) and may carry a different CRS; ag-cube-cm requires them on the same grid | Reproject soil to CHIRPS CRS and resolution in one step: `soil.rio.write_crs("EPSG:4326").rio.reproject_match(weather_ds, resampling="bilinear").to_netcdf("soil_resampled.nc")` — then update `soil_path` in the config |
| All pixels skipped: soil slice is all NaN | Soil cube coordinates are in projected metres, not degrees — `sel(y,x)` lands outside the data | Rebuild soil cube with `crs='+proj=igh ...'` and `target_crs='EPSG:4326'` (see `soil-data-download` skill) |
| All pixels skipped: `no valid index for a 0-dimensional object` | Soil cube is in flat format (`clay_0-5cm_mean`) — needs reshaping | Run `reshape_flat_soil_cube(ds).to_netcdf(...)` then re-run simulation |
| `UnicodeEncodeError` | Non-ASCII chars in output path on Windows | Use ASCII-only paths |
| `ModuleNotFoundError: mcp` | mcp package not installed | `pip install mcp` |
| Slow simulation | `ncores` too low | Set `ncores` to number of physical CPU cores |
