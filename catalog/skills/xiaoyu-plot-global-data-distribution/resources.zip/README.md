直接给文件名，再也不用打开代码软件才能查看数据对不对了，还能看数据的分布情况，支持地学中常见的数据文件：

NetCDF（ERA5、CMIP6、WRF）
GRIB（ECMWF原始资料）
HDF5（卫星降水TRMM/GPM）
GeoTIFF（空间遥感）
CSV/TXT（站点资料）

使用方法：在codex中输入指令：利用plot-global-data-distribution这个skill分析xxxxxx.nc文件
试了一下2m温度数据:
<img width="3595" height="1678" alt="image" src="https://github.com/user-attachments/assets/6cf98785-4ab5-4a14-ad5d-cf3a75c84c9e" />
<img width="1712" height="1140" alt="image" src="https://github.com/user-attachments/assets/8a4c91f5-8f0d-4016-92e0-15c33fbc2d3e" />
还试了一下tif数据：
<img width="3497" height="2155" alt="image" src="https://github.com/user-attachments/assets/018ed3c6-9889-428d-9ab9-3e042bbe19f7" />
<img width="1746" height="1140" alt="image" src="https://github.com/user-attachments/assets/683d168f-54c9-452e-88a4-fddd8888d914" />
