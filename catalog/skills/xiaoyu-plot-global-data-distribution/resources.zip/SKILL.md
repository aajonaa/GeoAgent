---
name: plot-global-data-distribution
description: Read gridded geoscience data with automatic format detection and create publication-ready global distribution maps, histograms, or temporal trend maps using Sen slope and the Mann-Kendall test. Use for NetCDF, GeoTIFF, HDF5/HDF-EOS5, GRIB, Zarr, CSV, TXT/TSV, or Excel inputs; .nc/.nc4/.tif/.tiff/.h5/.hdf5/.he5/.grib/.grb/.zarr/.csv/.txt/.tsv/.xlsx/.xls files; spatial distributions, event frequencies, occurrence counts, automatic coordinate detection, trend analysis, MK significance, or 300 dpi scientific figures.
---

# Plot Global Data Distribution

Create global distribution or trend figures with `scripts/plot_global_distribution.py`.

## Workflow

1. Collect the input file, title, unit, and requested analysis. Treat the format, variable, and coordinate names as optional.
2. Auto-detect the format from the extension and file signature. Inspect the dataset if several spatial variables are plausible or dimensions need selection.
3. Run distribution analysis for spatial frequency/aggregation, or trend analysis for Sen slope and original Mann-Kendall significance.
4. Inspect the PNG and sibling `*.stats.json`; rerun if labels, clipping, or dimension reduction require adjustment.
5. Return both outputs and state the aggregation or trend method, detected time dimension, slope time unit, alpha, and any extra-dimension reduction.

## Distribution command

```bash
python scripts/plot_global_distribution.py INPUT \
  --analysis distribution \
  --variable VARIABLE \
  --title "Global distribution of extreme event-days" \
  --unit "event-days" \
  --output OUTPUT.png
```

Distribution options:

- `--mode count-positive`: count finite values greater than `--threshold` across every non-spatial dimension; default.
- `--mode sum`, `mean`, or `snapshot`: sum, average, or directly plot 2-D data.
- `--vmax-percentile 99`: control upper color clipping.
- `--bins 30`: set histogram bins.

## Trend command

```bash
python scripts/plot_global_distribution.py INPUT \
  --analysis trend \
  --variable VARIABLE \
  --title "Global temperature trend" \
  --unit "°C" \
  --slope-unit year \
  --alpha 0.05 \
  --output OUTPUT.png
```

Trend behavior and options:

- Auto-detect time from common names, CF `standard_name=time`, or `axis=T`; use `--time-name` to override.
- Compute the Sen slope as the median of all pairwise slopes at each grid cell.
- Apply the original Mann-Kendall test with tie-corrected variance; stipple cells where `p < --alpha`. The original test assumes temporal independence.
- Require at least `--min-observations 8` finite observations per cell.
- Convert datetime and cftime coordinates to `--slope-unit year|day`; numeric time uses native units.
- Reject duplicate times and extra dimensions by default. Use `--reduce-extra mean|sum` only when scientifically justified.
- Treat the MK result as an uncorrected grid-cell test. Do not describe it as field-significant or multiple-testing corrected.

## Shared controls

- Auto-detect NetCDF, GeoTIFF, HDF5/HDF-EOS5, GRIB, Zarr, CSV, TXT/TSV, and Excel. Use `--input-format` only when detection fails.
- Read CSV, TXT/TSV, and Excel as long-form tables with one row per observation. Require uniquely named `lat|latitude|y` and `lon|longitude|x` columns; detect an optional `time|date|datetime|valid_time|year` column.
- Treat remaining numeric table columns as candidate variables. Use `--variable` when more than one exists. Reject duplicate coordinate rows instead of aggregating silently.
- Auto-detect common CSV/TXT delimiters. Use `--sheet-name NAME_OR_INDEX` for Excel; default to the first sheet.
- Require geographic longitude/latitude GeoTIFFs; reproject projected or rotated rasters before plotting.
- For multi-band GeoTIFFs, use `--mode mean|sum` to aggregate bands. Use a 2-D single-band raster with `snapshot`.
- Read CF-compatible HDF5 directly through xarray. For generic HDF5, scan numeric datasets and require unique 1-D latitude and longitude datasets.
- Require `rasterio` for GeoTIFF, `h5py` for generic HDF5, `cfgrib` plus ecCodes for GRIB, a Zarr backend for Zarr, pandas for tables, and openpyxl/xlrd for Excel.
- Omit `--variable` only when one numeric variable contains latitude and longitude.
- Use `--lat-name`, `--lon-name`, and `--time-name` for ambiguous coordinates.
- Default to `--dpi 300` for publication-grade PNG output; never lower it unless requested.
- Omit `--output` to write beside the input file.

## Interpretation rules

- Exclude zero-frequency cells from distribution map color and histogram.
- Preserve oceans, land, lakes, coastlines, and light graticules.
- Label trend colors as source unit per detected slope time unit.
- Do not silently select among several plausible variables or silently collapse extra trend dimensions.
- Report missing Cartopy instead of substituting a misleading unprojected map.

## Outputs

- A 300 dpi PNG containing the global map and histogram.
- A sibling `*.stats.json` containing source details, detected coordinates, method settings, summary statistics, output DPI, and trend significance counts when applicable.
