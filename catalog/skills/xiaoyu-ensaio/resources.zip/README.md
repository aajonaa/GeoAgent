# 地学公开数据集版本化获取（ensaio）

按明确的数据集名称和版本获取 Fatiando 系列示例资料，并保留原始文件、来源与校验信息。

原始 skill 目录：`ensaio/`。核心入口为 `SKILL.md`；随附脚本和参考资料保留原始目录结构。

源码：https://github.com/SteadfastAsArt/geoscience-skills/tree/c1eb8e67c67ab714d0599461058e4a350d95cb1d/ensaio

版本：`c1eb8e67c67ab714d0599461058e4a350d95cb1d`。

将 `ensaio/` 作为独立 skill 目录使用。运行所需 Python 库及外部程序见 `SKILL.md`，需在使用环境中另行安装。

原始文件内容未修改。本压缩包额外附带本说明和上游许可证；不包含本地运行环境、缓存或个人数据。
