# Data formats

## Preferred: complete path table

Each row is one complete route through all ordered layers. `value` is an additive weight.

```csv
Habitat status,Spatial component,Taxon,Region,value
Unoccupied,Barrier isolated,Amphibians,Indomalayan,12.4
Unoccupied,Barrier isolated,Amphibians,Neotropical,8.1
Native,Non-contiguous,Reptiles,Afrotropical,3.2
```

Duplicate paths are allowed and are summed. This format preserves how a quantity moves from the first through the last layer.

If `--layers` is omitted, the renderer treats all columns except the value column as layers in file order. Recognized value names include `value`, `weight`, `count`, `amount`, `area`, `proportion`, `数值`, `数量`, `权重`, `面积`, and `占比`.

## Alternative: adjacent-link table

Each row describes one connection.

```csv
source,target,value,source_layer,target_layer
A,X,40,0,1
B,X,20,0,1
X,M,35,1,2
X,N,25,1,2
```

Required columns are `source`, `target`, and `value`. Layer columns are optional. Provide zero-based integer `source_layer` and `target_layer` when labels repeat across layers or when explicit positioning matters. Without them, labels are treated as globally unique and layers are inferred from an acyclic graph.

Prefer adjacent layers. A link may skip a layer, but the visual meaning must be intentional. Cycles cannot be represented as left-to-right layers.

## Raw observation table

One row per observation can be converted to a path table by grouping all layer columns and summing a numeric weight. For unweighted observations, add `value = 1`, then aggregate.

## Meaning of value

Valid examples include individuals, species, pixels, square kilometres, dollars, tonnes, joules, or a common-denominator proportion. Values must be non-negative and additive. Category scores, ranks, means, correlation coefficients, and independently normalized percentages are usually not valid flow widths without a defensible transformation.

