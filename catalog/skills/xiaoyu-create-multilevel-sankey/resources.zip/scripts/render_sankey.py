#!/usr/bin/env python3
"""Render layered path or link data as an offline HTML/SVG Sankey diagram."""

from __future__ import annotations

import argparse
import csv
import html
import json
import math
import sys
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path


VALUE_NAMES = {
    "value", "weight", "count", "amount", "area", "proportion",
    "数值", "数量", "权重", "面积", "占比",
}
DEFAULT_COLORS = [
    "#3E8E93", "#46AE91", "#83B84A", "#9A63E8", "#DE4A42",
    "#F39A4B", "#C34A9B", "#75B84A", "#4D8ABF", "#43AEB5",
    "#506FD0", "#E39A43", "#F2C84B", "#7D789E", "#9C938E",
]


@dataclass
class Node:
    key: tuple
    label: str
    layer: int
    order: int
    value: float = 0.0
    x: float = 0.0
    y: float = 0.0
    h: float = 0.0
    color: str = ""


@dataclass
class Link:
    source: tuple
    target: tuple
    value: float
    order: int
    sy: float = 0.0
    ty: float = 0.0
    h: float = 0.0


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path, help="CSV, TSV, or JSON array input")
    p.add_argument("--format", choices=("auto", "path", "links"), default="auto")
    p.add_argument("--layers", help="Comma-separated ordered layer columns for path format")
    p.add_argument("--value", help="Numeric value column (default: infer common name)")
    p.add_argument("--output", type=Path, required=True, help="Output .html or .svg")
    p.add_argument("--title", default="Sankey diagram")
    p.add_argument("--unit", default="")
    p.add_argument("--width", type=int, default=1400)
    p.add_argument("--height", type=int, default=800)
    p.add_argument("--margin", type=int, default=70)
    p.add_argument("--node-width", type=int, default=24)
    p.add_argument("--node-gap", type=int, default=16)
    p.add_argument("--link-opacity", type=float, default=0.52)
    p.add_argument("--palette", help="Comma-separated CSS colors")
    p.add_argument("--sort", choices=("input", "value"), default="input")
    p.add_argument("--decimals", type=int, default=3)
    p.add_argument("--hide-values", action="store_true")
    return p.parse_args()


def die(message: str) -> None:
    raise SystemExit(f"Error: {message}")


def read_rows(path: Path) -> tuple[list[dict[str, object]], list[str]]:
    if not path.exists():
        die(f"input file not found: {path}")
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, list) or not all(isinstance(x, dict) for x in data):
            die("JSON input must be an array of objects")
        fields = list(data[0]) if data else []
        return data, fields
    text = path.read_text(encoding="utf-8-sig")
    if not text.strip():
        die("input file is empty")
    delimiter = "\t" if path.suffix.lower() == ".tsv" else None
    if delimiter is None:
        try:
            delimiter = csv.Sniffer().sniff(text[:4096], delimiters=",\t;").delimiter
        except csv.Error:
            delimiter = ","
    reader = csv.DictReader(text.splitlines(), delimiter=delimiter)
    fields = reader.fieldnames or []
    return list(reader), fields


def numeric(raw: object, row_number: int, column: str) -> float:
    try:
        value = float(str(raw).strip())
    except (TypeError, ValueError):
        die(f"row {row_number}: {column!r} must be numeric, got {raw!r}")
    if not math.isfinite(value) or value < 0:
        die(f"row {row_number}: {column!r} must be finite and non-negative")
    return value


def infer_value(fields: list[str], requested: str | None) -> str:
    if requested:
        if requested not in fields:
            die(f"value column {requested!r} is missing")
        return requested
    matches = [f for f in fields if f.strip().lower() in VALUE_NAMES]
    if len(matches) != 1:
        die("cannot infer one value column; pass --value COLUMN")
    return matches[0]


def parse_path(rows, fields, value_col, layer_cols):
    for col in [*layer_cols, value_col]:
        if col not in fields:
            die(f"column {col!r} is missing")
    nodes: dict[tuple, Node] = {}
    node_order = 0
    link_values = defaultdict(float)
    link_order = {}
    skipped = 0
    for rn, row in enumerate(rows, 2):
        val = numeric(row.get(value_col), rn, value_col)
        if val == 0:
            skipped += 1
            continue
        keys = []
        for layer, col in enumerate(layer_cols):
            label = str(row.get(col, "")).strip()
            if not label:
                die(f"row {rn}: layer {col!r} is empty")
            key = (layer, label)
            keys.append(key)
            if key not in nodes:
                nodes[key] = Node(key, label, layer, node_order)
                node_order += 1
            nodes[key].value += val
        for layer in range(len(keys) - 1):
            pair = (keys[layer], keys[layer + 1])
            if pair not in link_order:
                link_order[pair] = len(link_order)
            link_values[pair] += val
    links = [Link(a, b, v, link_order[(a, b)]) for (a, b), v in link_values.items()]
    return nodes, links, skipped, []


def infer_layers(edges: list[tuple[str, str]]) -> dict[str, int]:
    vertices = set(x for edge in edges for x in edge)
    indegree = {v: 0 for v in vertices}
    outgoing = defaultdict(list)
    for a, b in edges:
        if a == b:
            die(f"self-cycle at {a!r}")
        outgoing[a].append(b)
        indegree[b] += 1
    q = deque(v for v in vertices if indegree[v] == 0)
    rank = {v: 0 for v in q}
    seen = 0
    while q:
        a = q.popleft()
        seen += 1
        for b in outgoing[a]:
            rank[b] = max(rank.get(b, 0), rank[a] + 1)
            indegree[b] -= 1
            if indegree[b] == 0:
                q.append(b)
    if seen != len(vertices):
        die("link graph contains a cycle; provide acyclic left-to-right data")
    return rank


def parse_links(rows, fields, value_col):
    for col in ("source", "target", value_col):
        if col not in fields:
            die(f"link format requires column {col!r}")
    explicit = "source_layer" in fields and "target_layer" in fields
    raw = []
    skipped = 0
    for rn, row in enumerate(rows, 2):
        a, b = str(row.get("source", "")).strip(), str(row.get("target", "")).strip()
        if not a or not b:
            die(f"row {rn}: source and target cannot be empty")
        val = numeric(row.get(value_col), rn, value_col)
        if val == 0:
            skipped += 1
            continue
        if explicit:
            try:
                la, lb = int(str(row["source_layer"])), int(str(row["target_layer"]))
            except (TypeError, ValueError):
                die(f"row {rn}: layer columns must be integers")
            if la < 0 or lb <= la:
                die(f"row {rn}: target_layer must be greater than source_layer")
        else:
            la = lb = -1
        raw.append((a, b, val, la, lb))
    if not raw:
        die("no positive flows found")
    if not explicit:
        rank = infer_layers([(a, b) for a, b, *_ in raw])
        raw = [(a, b, v, rank[a], rank[b]) for a, b, v, *_ in raw]
    nodes = {}
    node_order = 0
    link_values = defaultdict(float)
    link_order = {}
    incoming, outgoing = defaultdict(float), defaultdict(float)
    for a, b, val, la, lb in raw:
        ka, kb = (la, a), (lb, b)
        for key, label, layer in ((ka, a, la), (kb, b, lb)):
            if key not in nodes:
                nodes[key] = Node(key, label, layer, node_order)
                node_order += 1
        pair = (ka, kb)
        if pair not in link_order:
            link_order[pair] = len(link_order)
        link_values[pair] += val
        outgoing[ka] += val
        incoming[kb] += val
    warnings = []
    for key, node in nodes.items():
        inc, out = incoming[key], outgoing[key]
        node.value = max(inc, out)
        if inc and out and abs(inc - out) > 1e-8 * max(1.0, inc, out):
            warnings.append(f"{node.label!r} (layer {node.layer}) inflow {inc:g} != outflow {out:g}")
    links = [Link(a, b, v, link_order[(a, b)]) for (a, b), v in link_values.items()]
    return nodes, links, skipped, warnings


def fmt(value: float, decimals: int, unit: str) -> str:
    rendered = f"{value:,.{decimals}f}".rstrip("0").rstrip(".")
    return f"{rendered} {unit}".strip()


def render(nodes, links, args) -> str:
    if not nodes or not links:
        die("at least one positive link is required")
    layers = sorted({n.layer for n in nodes.values()})
    layer_index = {layer: i for i, layer in enumerate(layers)}
    if len(layers) < 2:
        die("at least two layers are required")
    palette = [x.strip() for x in args.palette.split(",")] if args.palette else DEFAULT_COLORS
    palette = [x for x in palette if x]
    if not palette:
        die("palette cannot be empty")
    top = args.margin + 48
    bottom = args.height - args.margin
    usable = bottom - top
    left, right = args.margin + 100, args.width - args.margin - 100
    step = (right - left - args.node_width) / (len(layers) - 1)
    grouped = defaultdict(list)
    for n in nodes.values():
        grouped[n.layer].append(n)
    for group in grouped.values():
        group.sort(key=(lambda n: (-n.value, n.order)) if args.sort == "value" else (lambda n: n.order))
    scales = []
    for layer in layers:
        total = sum(n.value for n in grouped[layer])
        space = usable - args.node_gap * (len(grouped[layer]) - 1)
        if total <= 0 or space <= 0:
            die("diagram is too short for the requested node gap")
        scales.append(space / total)
    scale = min(scales)
    for layer in layers:
        group = grouped[layer]
        occupied = sum(n.value * scale for n in group) + args.node_gap * (len(group) - 1)
        y = top + (usable - occupied) / 2
        for n in group:
            n.x = left + layer_index[layer] * step
            n.y = y
            n.h = n.value * scale
            n.color = palette[n.order % len(palette)]
            y += n.h + args.node_gap
    outgoing_links, incoming_links = defaultdict(list), defaultdict(list)
    for link in links:
        link.h = link.value * scale
        outgoing_links[link.source].append(link)
        incoming_links[link.target].append(link)
    for key, items in outgoing_links.items():
        items.sort(key=lambda e: (nodes[e.target].y, e.order))
        offset = nodes[key].y
        for e in items:
            e.sy = offset
            offset += e.h
    for key, items in incoming_links.items():
        items.sort(key=lambda e: (nodes[e.source].y, e.order))
        offset = nodes[key].y
        for e in items:
            e.ty = offset
            offset += e.h
    pieces = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{args.width}" height="{args.height}" viewBox="0 0 {args.width} {args.height}" role="img" aria-label="{html.escape(args.title)}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{args.width/2:g}" y="38" text-anchor="middle" font-family="Arial, sans-serif" font-size="24" font-weight="700" fill="#202124">{html.escape(args.title)}</text>',
        '<defs>',
    ]
    for i, e in enumerate(links):
        s, t = nodes[e.source], nodes[e.target]
        pieces.append(f'<linearGradient id="g{i}" gradientUnits="userSpaceOnUse" x1="{s.x + args.node_width:g}" x2="{t.x:g}"><stop offset="0" stop-color="{s.color}"/><stop offset="1" stop-color="{t.color}"/></linearGradient>')
    pieces.append('</defs><g class="links">')
    for i, e in enumerate(links):
        s, t = nodes[e.source], nodes[e.target]
        x1, x2 = s.x + args.node_width, t.x
        c1, c2 = x1 + (x2 - x1) * 0.45, x1 + (x2 - x1) * 0.55
        y1a, y1b, y2a, y2b = e.sy, e.sy + e.h, e.ty, e.ty + e.h
        d = f'M{x1:g},{y1a:g} C{c1:g},{y1a:g} {c2:g},{y2a:g} {x2:g},{y2a:g} L{x2:g},{y2b:g} C{c2:g},{y2b:g} {c1:g},{y1b:g} {x1:g},{y1b:g} Z'
        tip = f'{s.label} → {t.label}: {fmt(e.value, args.decimals, args.unit)}'
        pieces.append(f'<path d="{d}" fill="url(#g{i})" fill-opacity="{args.link_opacity:g}" stroke="none"><title>{html.escape(tip)}</title></path>')
    pieces.append('</g><g class="nodes">')
    first_layer, last_layer = layers[0], layers[-1]
    for n in sorted(nodes.values(), key=lambda x: (x.layer, x.y)):
        tip = f'{n.label}: {fmt(n.value, args.decimals, args.unit)}'
        pieces.append(f'<rect x="{n.x:g}" y="{n.y:g}" width="{args.node_width}" height="{max(n.h, 0.8):g}" rx="1.5" fill="{n.color}" stroke="#ffffff" stroke-width="0.7"><title>{html.escape(tip)}</title></rect>')
        if n.layer == first_layer:
            tx, anchor = n.x - 8, "end"
        elif n.layer == last_layer:
            tx, anchor = n.x + args.node_width + 8, "start"
        else:
            tx, anchor = n.x + args.node_width / 2, "middle"
        ty = n.y + n.h / 2
        value_text = "" if args.hide_values else f'<tspan x="{tx:g}" dy="15" font-size="11" font-weight="400">{html.escape(fmt(n.value, args.decimals, args.unit))}</tspan>'
        pieces.append(f'<text x="{tx:g}" y="{ty:g}" text-anchor="{anchor}" dominant-baseline="middle" font-family="Arial, sans-serif" font-size="12" font-weight="600" fill="#202124" stroke="white" stroke-width="3" paint-order="stroke"><tspan x="{tx:g}">{html.escape(n.label)}</tspan>{value_text}</text>')
    pieces.append('</g></svg>')
    return "\n".join(pieces)


def main() -> None:
    args = parse_args()
    if args.width < 600 or args.height < 400:
        die("use at least --width 600 and --height 400")
    if not 0 <= args.link_opacity <= 1:
        die("--link-opacity must be between 0 and 1")
    rows, fields = read_rows(args.input)
    if not rows:
        die("input has no data rows")
    value_col = infer_value(fields, args.value)
    file_format = args.format
    if file_format == "auto":
        file_format = "links" if {"source", "target"}.issubset(fields) else "path"
    if file_format == "path":
        layer_cols = [x.strip() for x in args.layers.split(",")] if args.layers else [f for f in fields if f != value_col]
        if len(layer_cols) < 2:
            die("path format requires at least two layer columns")
        nodes, links, skipped, warnings = parse_path(rows, fields, value_col, layer_cols)
    else:
        nodes, links, skipped, warnings = parse_links(rows, fields, value_col)
    svg = render(nodes, links, args)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    suffix = args.output.suffix.lower()
    if suffix == ".svg":
        args.output.write_text(svg, encoding="utf-8")
        outputs = [args.output]
    elif suffix == ".html":
        svg_path = args.output.with_suffix(".svg")
        svg_path.write_text(svg, encoding="utf-8")
        warning_html = "" if not warnings else '<div class="warnings"><strong>Validation warnings:</strong><ul>' + "".join(f'<li>{html.escape(w)}</li>' for w in warnings) + '</ul></div>'
        document = f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(args.title)}</title><style>body{{margin:0;background:#f4f5f7;font-family:Arial,sans-serif;color:#202124}}main{{max-width:{args.width}px;margin:24px auto;padding:16px;background:white;box-shadow:0 2px 16px #0001;overflow:auto}}svg{{display:block;max-width:none}}.warnings{{margin:12px;padding:12px 16px;background:#fff4dc;border-left:4px solid #e19a22}}</style></head><body><main>{warning_html}{svg}</main></body></html>'''
        args.output.write_text(document, encoding="utf-8")
        outputs = [args.output, svg_path]
    else:
        die("output extension must be .html or .svg")
    print(json.dumps({
        "status": "ok", "format": file_format, "nodes": len(nodes), "links": len(links),
        "skipped_zero_rows": skipped, "warnings": warnings,
        "outputs": [str(p.resolve()) for p in outputs],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
