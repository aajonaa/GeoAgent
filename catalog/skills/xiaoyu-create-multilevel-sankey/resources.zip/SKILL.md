---
name: create-multilevel-sankey
description: Create publication-ready multilevel Sankey/alluvial diagrams from user-provided layered path data or source-target-value link data. Use when users ask to draw, generate, revise, or validate Sankey diagrams, alluvial plots, flow diagrams, or multi-stage categorical flows with an arbitrary number of layers, including requests involving CSV, TSV, JSON, counts, areas, amounts, weights, or proportions.
---

# Create Multilevel Sankey

Create a Sankey diagram from a complete path table whenever possible. Use the bundled renderer so the result is deterministic and works without online chart libraries.

## Workflow

1. Identify the tracked quantity. Confirm whether `value` means count, area, money, mass, probability, proportion, or another additive measure.
2. Identify whether layers represent time, process stages, classification dimensions, or source-to-destination steps. Do not imply time or causality unless the data supports it.
3. Prefer a path table with one column per ordered layer plus one numeric value column. Accept a link table when only pairwise flows are available. Read [references/data-formats.md](references/data-formats.md) when interpreting or restructuring inputs.
4. Resolve only ambiguities that materially affect the diagram. Otherwise infer the value column from common English or Chinese names, preserve layer order from the file, aggregate duplicate paths, and report the assumptions.
5. Validate before rendering:
   - reject missing layer values, non-numeric values, negative values, and non-finite values;
   - omit zero-value rows with a notice;
   - verify that all values use one unit;
   - for link tables, check internal-node inflow and outflow and warn about imbalances;
   - warn when overlapping category membership may double-count the tracked quantity.
6. Run `scripts/render_sankey.py`. Place user-facing outputs in the active task's output/deliverable directory, not inside this skill.
7. Inspect the generated SVG or HTML visually. Check label clipping, excessive crossings, node order, colors, and whether small flows remain legible. Revise dimensions or input ordering when needed.
8. Return clickable links to the HTML and SVG. State the unit, layer interpretation, normalization, and any validation warnings.

## Rendering

For a path table:

```bash
python3 scripts/render_sankey.py data.csv --format path \
  --layers "Stage 1,Stage 2,Stage 3" --value value \
  --output sankey.html --title "Flow through three stages" --unit "km²"
```

For a link table:

```bash
python3 scripts/render_sankey.py links.csv --format links \
  --output sankey.html --title "Flows" --unit "%"
```

The renderer accepts CSV, TSV, and JSON arrays. HTML output automatically includes a companion SVG. Use `--help` for layout and styling controls.

## Design rules

- Keep all layers in the same additive unit.
- Use proportions only when they share the same denominator. Do not connect unrelated percentages merely because each layer sums to 100%.
- Preserve full-path data when available; pairwise marginal links cannot always reconstruct end-to-end paths.
- Treat node values as the sum of incident flows, not as an independent field.
- Use a descriptive title and include the unit in the subtitle or labels.
- Prefer 3–8 layers and a manageable number of nodes per layer. If the chart becomes dense, aggregate rare categories or split it into focused diagrams.
- Explain that a Sankey diagram shows allocation or association; it does not by itself establish causality.

