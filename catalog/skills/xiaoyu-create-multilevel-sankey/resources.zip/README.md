# `create-multilevel-sankey` Skill 使用说明

## 目录

1. Skill 定位
2. 适用场景
3. 数值 `value` 的含义
4. 支持的数据格式
5. 调用方式
6. 推荐提示词模板
7. 自动校验规则
8. 输出文件
9. 样式配置能力
10. 命令行调用（高级用法）
11. 使用边界和注意事项
12. 一句话调用示例

## 1. Skill 定位

`create-multilevel-sankey` 是一个用于创建、检查和修改多层桑基图（Sankey diagram）或河流图（alluvial diagram）的 Codex Skill。

它面向以下任务：

- 将多阶段、多年份或多维分类数据绘制为桑基图；
- 支持任意层数，而非限定为两层或三层；
- 根据流量大小自动控制节点和流带宽度；
- 检查负数、空值、重复路径、循环和流量不守恒；
- 输出可交互 HTML 和可编辑 SVG，必要时进一步导出 PNG；
- 调整标题、单位、标签、节点排序、颜色、透明度、字体和画布尺寸。

这里的“层”可以表示：

- 时间：2000 → 2005 → 2010 → 2015；
- 流程：原料 → 加工 → 产品 → 市场；
- 分类：样本 → 类群 → 地区 → 风险等级；
- 来源和去向：资金来源 → 使用部门 → 项目。

桑基图展示的是数量的分配、转移或关联关系，本身不能证明因果关系。

## 2. 适用场景

### 2.1 适合使用

- 土地利用或土地覆盖转换；
- 人口迁移、用户路径和状态转移；
- 能源、物质、水汽或资金流动；
- 供应链和生产流程；
- 物种、栖息地或区域分类关系；
- 多年份类别转换；
- 具有明确 `来源—目标—数值` 的网络流数据。

### 2.2 不适合直接使用

- 只有各年份类别总量，没有类别之间的转移量；
- 数值是排名、相关系数、均值或不可相加的评分；
- 各层百分比使用了不同分母；
- 数据包含无法展开为从左到右结构的循环；
- 同一对象在一层同时属于多个类别，且没有定义拆分权重；
- 类别和流带过多，导致图形无法阅读。

例如，只有下面的数据不能还原真实土地转换流向：

| land_cover_type | area_2000 | area_2005 |
|---|---:|---:|
| Forest | 32,000 | 29,335 |
| Cropland | 28,000 | 25,483 |

它只能说明 Forest 减少、Cropland 减少，不能说明减少的面积转移到了什么类别。此时还需要 2000→2005 的土地转换矩阵或像元级轨迹数据。

## 3. 数值 `value` 的含义

`value` 决定流带宽度，必须是非负、有限且可相加的数量。

可以使用：

- 个数或样本数；
- 人数、用户数或物种数；
- 像元数；
- 面积，如 km²；
- 金额；
- 质量、能量或体积；
- 使用同一分母计算的比例或概率。

节点数值通常由流入或流出该节点的流带求和得到，不应与连接数据互相矛盾。

对于中间层节点，理想情况下应满足：

```text
流入总量 = 流出总量
```

## 4. 支持的数据格式

渲染器直接支持 UTF-8 编码的 CSV、TSV 和 JSON 数组。用户也可以在对话中粘贴 Markdown 表格，由 Codex 转换为可用格式。Excel 文件需要先转换或提取为上述格式。

### 4.1 完整路径宽表（推荐）

每一行表示一条从第一层到最后一层的完整路径；每一层对应一列，最后提供一个数值列。

```csv
Year2000,Year2005,Year2010,Year2015,value
Forest,Forest,Grassland,Grassland,1200
Forest,Cropland,Cropland,Urban,350
Cropland,Cropland,Urban,Urban,480
```

也可以用于非时间分类：

```csv
HabitatStatus,SpatialComponent,Taxon,Region,value
Unoccupied,Barrier isolated,Amphibians,Indomalayan,12.4
Unoccupied,Barrier isolated,Amphibians,Neotropical,8.1
Native,Non-contiguous,Reptiles,Afrotropical,3.2
```

要求：

- 至少两层；
- 层级列必须按从左到右的顺序排列；
- 每一行的所有层级值都不能为空；
- 重复路径允许存在，绘图前会自动求和；
- `value` 必须使用统一单位。

常见数值列名称可自动识别：`value`、`weight`、`count`、`amount`、`area`、`proportion`、`数值`、`数量`、`权重`、`面积`、`占比`。

### 4.2 连接关系长表

每一行描述一条来源到目标的连接。

```csv
source,target,value,source_layer,target_layer
Forest,Forest,16000,0,1
Forest,Cropland,8400,0,1
Cropland,Cropland,12700,0,1
Forest,Grassland,10900,1,2
```

字段说明：

| 字段 | 是否必需 | 含义 |
|---|---|---|
| `source` | 是 | 流带起点类别 |
| `target` | 是 | 流带终点类别 |
| `value` | 是 | 流量、面积、数量或比例 |
| `source_layer` | 建议 | 起点所在层，使用从 0 开始的整数 |
| `target_layer` | 建议 | 终点所在层，必须大于起点层 |

当同一类别名称会在多个年份重复出现时，必须提供层编号，避免不同年份的同名节点被混淆。

### 4.3 相邻年份转换矩阵

时间序列桑基图可以输入多张相邻年份转换矩阵，例如：

```text
transition_2000_2005.csv
transition_2005_2010.csv
transition_2010_2015.csv
```

单张矩阵格式：

```csv
from_to,Forest,Cropland,Grassland,Urban
Forest,16000,8400,3600,400
Cropland,8500,12700,4300,500
Grassland,1800,1300,10900,700
Urban,300,2100,800,5100
```

- 行表示来源类别；
- 列表示目标类别；
- 单元格表示从来源类别转入目标类别的数量；
- 每张矩阵会转换为连接关系长表；
- 相邻矩阵的中间年份边际总量必须一致。

建议同时提供各年份类别总量表，用于验证矩阵行和、列和：

```csv
land_cover_type,area_2000_km2,area_2005_km2,area_2010_km2,area_2015_km2
Forest,32000,29335,16076,15298
Cropland,28000,25483,20212,17441
```

### 4.4 原始观测表

当每一行表示一个样本、像元或对象时，可以将它转换为路径宽表。

```csv
pixel_id,year2000,year2005,year2010,year2015
P001,Forest,Forest,Grassland,Grassland
P002,Forest,Cropland,Cropland,Urban
```

无权重观测可先增加 `value = 1`，再按所有层级列分组求和。若每个像元面积不同，应使用像元面积作为 `value`。

### 4.5 JSON 数组

```json
[
  {"source": "Forest", "target": "Cropland", "value": 8400, "source_layer": 0, "target_layer": 1},
  {"source": "Forest", "target": "Forest", "value": 16000, "source_layer": 0, "target_layer": 1}
]
```

## 5. 调用方式

### 5.1 基础调用

在提示词中明确写出 Skill 名称：

```text
使用 $create-multilevel-sankey，根据我提供的数据绘制桑基图。
```

### 5.2 附件调用

上传 CSV、TSV 或 JSON 文件后输入：

```text
使用 $create-multilevel-sankey 绘制四层桑基图。
从左到右是 2000、2005、2010、2015 年，数值表示土地覆盖面积，单位为 km²。
请先校验各年份总量和转移矩阵是否守恒。
```

### 5.3 粘贴表格调用

```text
使用 $create-multilevel-sankey，把下面的路径宽表绘制成三层桑基图。
第一层到第三层分别是来源、部门和项目，value 表示金额，单位为万元。

| 来源 | 部门 | 项目 | value |
|---|---|---|---:|
| 财政 | 教育 | 学校建设 | 300 |
| 财政 | 医疗 | 医院改造 | 250 |
```

### 5.4 指定样式

```text
使用 $create-multilevel-sankey 绘图，并采用以下样式：
- 标题：Land-cover transitions, 2000–2015
- 类别名称放在节点左侧
- 数值旋转 90°放在色块内部
- 文字不使用白色描边
- 同一类别跨年份保持相同颜色
- 输出 HTML、SVG 和 PNG
```

### 5.5 修改已有图表

```text
使用 $create-multilevel-sankey 修改刚才的桑基图：
- 主标题保持不变
- 其他字体增大 2
- 另外生成两套配色，不覆盖原图
```

## 6. 推荐提示词模板

```text
使用 $create-multilevel-sankey，根据附件绘制桑基图。

层级顺序：<第一层> → <第二层> → <第三层> → <第四层>
数值含义：<面积/人数/金额/数量/比例>
单位：<km²/人/万元/%>
标题：<图表标题>
颜色规则：<按类别固定色/按层固定色/自定义颜色>
标签规则：<类别位置、数值位置、字号>
输出格式：HTML、SVG、PNG

绘图前请检查：
1. 空值、负数和重复路径；
2. 相邻层的流量是否守恒；
3. 各层是否使用同一单位和分母；
4. 是否存在重复计算。
```

## 7. 自动校验规则

Skill 在绘制前应执行以下检查：

1. 拒绝缺失的层级类别；
2. 拒绝非数字、负数和无穷值；
3. 忽略零值流，并报告忽略数量；
4. 自动聚合重复连接或重复路径；
5. 检查连接图是否包含循环；
6. 检查中间节点流入与流出是否一致；
7. 检查各层是否使用统一单位；
8. 比例数据必须共享同一分母；
9. 提醒可能存在的类别重叠和重复计算；
10. 时间转换矩阵应与年度总量表相互吻合。

当转换矩阵与年度面积总量不一致时，不应悄悄修改数据。可以：

- 要求用户修正数据；或
- 经明确说明后使用 RAS/IPF 等方法配平，并输出配平后的连接数据和调整说明。

## 8. 输出文件

主要输出：

| 格式 | 用途 |
|---|---|
| HTML | 浏览器中交互查看，支持悬停读取流量 |
| SVG | 矢量编辑、论文排版和高质量打印 |
| PNG | 预览、报告插图和演示文稿；在环境支持时导出 |
| CSV | 整理后的连接长表或配平后的流量数据 |

建议优先保留 SVG，因为它可以在 Illustrator、Inkscape、PowerPoint 等工具中继续编辑。

## 9. 样式配置能力

可调整内容包括：

- 标题和单位；
- 画布宽度和高度；
- 节点宽度和节点间距；
- 流带透明度；
- 节点排序；
- 数值小数位；
- 是否显示节点数值；
- 调色板；
- 按类别固定颜色；
- 按年份或层固定颜色；
- 相邻层之间的渐变颜色；
- 类别标签位置；
- 节点内数值旋转；
- 字号和字重。

## 10. 命令行调用（高级用法）

完整路径宽表：

```bash
python3 scripts/render_sankey.py data.csv \
  --format path \
  --layers "Year2000,Year2005,Year2010,Year2015" \
  --value value \
  --output sankey.html \
  --title "Land-cover transitions, 2000–2015" \
  --unit "km²"
```

连接长表：

```bash
python3 scripts/render_sankey.py links.csv \
  --format links \
  --output sankey.html \
  --title "Multilevel flows" \
  --unit "km²"
```

常用参数：

| 参数 | 说明 |
|---|---|
| `--format` | `auto`、`path` 或 `links` |
| `--layers` | 路径宽表中按顺序排列的层级列 |
| `--value` | 数值列名称 |
| `--output` | 输出 `.html` 或 `.svg` |
| `--title` | 图表标题 |
| `--unit` | 数值单位 |
| `--width` / `--height` | 画布尺寸 |
| `--node-width` | 节点宽度 |
| `--node-gap` | 节点间距 |
| `--link-opacity` | 流带透明度，范围 0–1 |
| `--palette` | 逗号分隔的 CSS 颜色 |
| `--sort` | 按输入顺序或数值排序 |
| `--decimals` | 数值小数位 |
| `--hide-values` | 隐藏节点数值 |

## 11. 使用边界和注意事项

- 相邻年份转换矩阵只能确定相邻时段流量，不能自动恢复每个对象贯穿所有年份的完整轨迹；
- 边际总量相同不代表转换关系唯一；
- 过多的节点和流带会显著降低可读性，必要时应合并小类别或拆分成多张图；
- 自动配色应考虑色盲友好、打印效果和文字对比度；
- SVG 和 HTML 是主输出，PNG 属于栅格化结果；
- 图中数值和单位必须在标题、副标题、标签或图注中明确说明。

## 12. 一句话调用示例

```text
使用 $create-multilevel-sankey，根据三张土地转换矩阵绘制 2000→2005→2010→2015 四层桑基图，流带表示面积（km²），同一类别跨年份保持同色，类别标在节点左侧，数值旋转 90°放在节点内，并输出 HTML、SVG 和 PNG。
```
