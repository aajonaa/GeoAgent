#!/usr/bin/env python3
"""Migrate checked-in source demos to the evidence-bound V4 exchange columns."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import tempfile
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import generate_demo_data
import source_adapters
import v4_semantics


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
DEFAULT_DEMOS = SKILL_DIR / "fixtures" / "source-demos"

# Contracts fulfilled by a hash-pinned combined fixture instead of a per-source
# generator demo. These sources are not in assets/source_manifest.json and are
# rebuilt from verified originals by their dedicated builder
# (fixtures/china/combined-v1 via scripts/build_china_demo.py).
# Every V4 source contract is now registry-backed; sources that exist only in
# combined fixtures (none currently) would be declared here.
COMBINED_FIXTURE_CONTRACTS: tuple[str, ...] = ()


class MigrationError(RuntimeError):
    """Raised when fixture migration cannot preserve one-to-one evidence."""


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _csv_bytes(rows: Sequence[Mapping[str, str]]) -> bytes:
    with tempfile.TemporaryFile("w+", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=generate_demo_data.INPUT_COLUMNS,
            extrasaction="raise",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
        handle.seek(0)
        return handle.read().encode("utf-8")


def _atomic_bytes(path: Path, value: bytes) -> None:
    with tempfile.NamedTemporaryFile("wb", dir=path.parent, delete=False) as handle:
        handle.write(value)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def _atomic_json(path: Path, value: Any) -> None:
    _atomic_bytes(
        path,
        (
            json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        ).encode(),
    )


def _jsonl_bytes(rows: Sequence[Mapping[str, Any]]) -> bytes:
    return "".join(
        json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
        for row in rows
    ).encode("utf-8")


def expected_fixture(
    source_id: str,
    fixture_dir: Path,
    registry: Mapping[str, Any],
) -> tuple[bytes, bytes, dict[str, Any]]:
    input_path = fixture_dir / "demo_input.csv"
    evidence_path = fixture_dir / "sources.jsonl"
    manifest_path = fixture_dir / "run_manifest.json"
    with input_path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    evidence = [
        json.loads(line)
        for line in evidence_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(rows) != len(evidence) or not rows:
        raise MigrationError(
            f"{source_id} does not have one evidence row per observation"
        )
    registry_sources = registry.get("sources")
    if not isinstance(registry_sources, Mapping) or source_id not in registry_sources:
        raise MigrationError(f"{source_id} is absent from source registry")
    source_entry = registry_sources[source_id]
    hash_by_filename = {
        str(item.get("filename")): str(item.get("expected_sha256"))
        for item in (source_entry.get("download", {}).get("files", []))
        if isinstance(item, Mapping)
        and item.get("filename")
        and item.get("expected_sha256")
    }
    normalized_evidence: list[dict[str, Any]] = []
    for item in evidence:
        normalized = dict(item)
        if normalized.get("source_file"):
            normalized["source_file"] = str(normalized["source_file"]).split("#", 1)[0]
        if not normalized.get("source_file_sha256"):
            filename = str(normalized.get("source_file") or "")
            expected_hash = hash_by_filename.get(filename)
            if expected_hash:
                normalized["source_file"] = filename
                normalized["source_file_sha256"] = expected_hash
        normalized_evidence.append(normalized)
    normalized_rows: list[dict[str, str]] = []
    for row in rows:
        normalized = dict(row)
        if normalized.get("source_file"):
            normalized["source_file"] = normalized["source_file"].split("#", 1)[0]
        normalized_rows.append(normalized)
    enriched = [
        v4_semantics.enrich_row(
            row, item, source_entry, str(registry.get("verified_at") or "")
        )
        for row, item in zip(normalized_rows, normalized_evidence, strict=True)
    ]
    content = _csv_bytes(enriched)
    evidence_content = _jsonl_bytes(normalized_evidence)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["exchange_schema"] = "d1-v4-exchange-v1"
    manifest["v4_semantics_version"] = v4_semantics.SEMANTICS_VERSION
    outputs = {str(item["path"]): item for item in manifest.get("outputs", [])}
    demo_output = outputs.get("demo_input.csv")
    if not isinstance(demo_output, dict):
        raise MigrationError(f"{source_id} manifest has no demo_input.csv output")
    demo_output["bytes"] = len(content)
    demo_output["sha256"] = _sha256_bytes(content)
    evidence_output = outputs.get("sources.jsonl")
    if not isinstance(evidence_output, dict):
        raise MigrationError(f"{source_id} manifest has no sources.jsonl output")
    evidence_output["bytes"] = len(evidence_content)
    evidence_output["sha256"] = _sha256_bytes(evidence_content)
    return content, evidence_content, manifest


def migrate(demo_root: Path, *, check: bool) -> dict[str, Any]:
    registry = source_adapters.load_source_registry()
    registry_sources = registry.get("sources")
    if not isinstance(registry_sources, Mapping):
        raise MigrationError("source registry has no sources object")
    contract_ids = set(v4_semantics.SOURCE_CONTRACTS)
    outside_registry = sorted(contract_ids - set(registry_sources))
    if outside_registry != sorted(COMBINED_FIXTURE_CONTRACTS):
        raise MigrationError(
            "source contracts outside the registry must be declared combined-"
            f"fixture contracts; found {outside_registry}, declared "
            f"{sorted(COMBINED_FIXTURE_CONTRACTS)}"
        )
    source_ids = sorted(contract_ids - set(COMBINED_FIXTURE_CONTRACTS))
    migrated: list[str] = []
    for source_id in source_ids:
        fixture_dir = demo_root / source_id
        content, evidence_content, manifest = expected_fixture(
            source_id, fixture_dir, registry
        )
        input_path = fixture_dir / "demo_input.csv"
        evidence_path = fixture_dir / "sources.jsonl"
        manifest_path = fixture_dir / "run_manifest.json"
        manifest_bytes = (
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        ).encode()
        if check:
            if input_path.read_bytes() != content:
                raise MigrationError(f"stale V4 demo CSV: {source_id}")
            if evidence_path.read_bytes() != evidence_content:
                raise MigrationError(f"stale V4 evidence JSONL: {source_id}")
            if manifest_path.read_bytes() != manifest_bytes:
                raise MigrationError(f"stale V4 demo manifest: {source_id}")
        else:
            _atomic_bytes(input_path, content)
            _atomic_bytes(evidence_path, evidence_content)
            _atomic_json(manifest_path, manifest)
        migrated.append(source_id)
    return {
        "status": "PASS",
        "source_count": len(migrated),
        "sources": migrated,
        "mode": "check" if check else "write",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--demo-root", type=Path, default=DEFAULT_DEMOS)
    parser.add_argument("--check", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        report = migrate(args.demo_root, check=args.check)
    except (OSError, ValueError, MigrationError, v4_semantics.SemanticError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
