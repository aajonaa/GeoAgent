# 地下水动态与含水层假设分析流程（hydrogeological-analysis）

组织地下水位、气象驱动及含水层解释，形成具有校准期、留出期和基线对比的分析结果。

原始 skill 目录：`workflows/hydrogeological-analysis/`。核心入口为 `SKILL.md`；随附脚本和参考资料保留原始目录结构。

源码：https://github.com/SteadfastAsArt/geoscience-skills/tree/c1eb8e67c67ab714d0599461058e4a350d95cb1d/workflows/hydrogeological-analysis

版本：`c1eb8e67c67ab714d0599461058e4a350d95cb1d`。

将 `hydrogeological-analysis/` 作为独立 skill 目录使用。运行所需 Python 库及外部程序见 `SKILL.md`，需在使用环境中另行安装。

原始文件内容未修改。本压缩包额外附带本说明和上游许可证；不包含本地运行环境、缓存或个人数据。
