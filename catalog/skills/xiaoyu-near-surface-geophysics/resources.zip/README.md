# 近地表地球物理处理与诊断流程（near-surface-geophysics）

组织 GPR、ERT 和 MT 资料的处理及证据比较，强调坐标、尺度与模型假设的一致性。

原始 skill 目录：`workflows/near-surface-geophysics/`。核心入口为 `SKILL.md`；随附脚本和参考资料保留原始目录结构。

源码：https://github.com/SteadfastAsArt/geoscience-skills/tree/c1eb8e67c67ab714d0599461058e4a350d95cb1d/workflows/near-surface-geophysics

版本：`c1eb8e67c67ab714d0599461058e4a350d95cb1d`。

将 `near-surface-geophysics/` 作为独立 skill 目录使用。运行所需 Python 库及外部程序见 `SKILL.md`，需在使用环境中另行安装。

原始文件内容未修改。本压缩包额外附带本说明和上游许可证；不包含本地运行环境、缓存或个人数据。
