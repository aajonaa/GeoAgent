#!/usr/bin/env python3
"""Plot a 2-D lon/lat field and its zonal profile with uncertainty."""

from __future__ import annotations

import argparse
import json
import math
import warnings
from pathlib import Path

import numpy as np


LAT_NAMES = ("lat", "latitude", "y")
LON_NAMES = ("lon", "longitude", "x")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input", type=Path)
    p.add_argument("--output", type=Path)
    p.add_argument("--variable")
    p.add_argument("--lat-name")
    p.add_argument("--lon-name")
    p.add_argument("--time-name")
    p.add_argument("--time-index", type=int)
    p.add_argument("--land-only", action="store_true")
    p.add_argument("--title", default="Spatial pattern and zonal profile")
    p.add_argument("--unit", default="")
    p.add_argument("--uncertainty", choices=("ci", "sd", "percentile", "none"), default="ci")
    p.add_argument("--confidence", type=float, default=0.95)
    p.add_argument("--percentiles", nargs=2, type=float, default=(2.5, 97.5), metavar=("LOW", "HIGH"))
    p.add_argument("--projection", choices=("robinson", "platecarree"), default="robinson")
    p.add_argument("--map-domain", choices=("auto", "global", "data"), default="auto",
                   help="Use -90..90 for global fields or the retained data latitude range.")
    p.add_argument("--cmap")
    p.add_argument("--vmin", type=float)
    p.add_argument("--vmax", type=float)
    p.add_argument("--center", type=float, default=0.0)
    p.add_argument("--lat-min", type=float)
    p.add_argument("--lat-max", type=float)
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--no-boundaries", action="store_true", help=argparse.SUPPRESS)
    return p


def choose_name(names, preferred, common, kind):
    if preferred:
        if preferred not in names:
            raise ValueError(f"{kind} name {preferred!r} not found; choices: {sorted(names)}")
        return preferred
    matches = [n for n in names if n.lower() in common]
    if len(matches) != 1:
        raise ValueError(f"Could not uniquely detect {kind}; choices: {sorted(names)}. Use --{kind}-name.")
    return matches[0]


def load_netcdf(path, variable, lat_name, lon_name, time_name=None, time_index=None):
    import xarray as xr

    ds = xr.open_dataset(path, decode_cf=True)
    names = set(ds.coords) | set(ds.variables)
    lat_name = choose_name(names, lat_name, LAT_NAMES, "lat")
    lon_name = choose_name(names, lon_name, LON_NAMES, "lon")
    if time_name is None:
        time_matches = [n for n in names if n.lower() in ("time", "date", "datetime", "valid_time")]
        time_name = time_matches[0] if len(time_matches) == 1 else None
    candidates = []
    for name, da in ds.data_vars.items():
        squeezed = da.squeeze(drop=True)
        spatial = lat_name in squeezed.dims and lon_name in squeezed.dims
        selectable = time_index is not None and time_name in squeezed.dims and squeezed.ndim == 3
        if spatial and (squeezed.ndim == 2 or selectable):
            candidates.append(name)
    if variable:
        if variable not in ds.data_vars:
            raise ValueError(f"Variable {variable!r} not found; choices: {sorted(ds.data_vars)}")
        candidates = [variable]
    if len(candidates) != 1:
        raise ValueError(f"Could not uniquely select a 2-D spatial variable; choices: {candidates}. Use --variable.")
    da = ds[candidates[0]].squeeze(drop=True)
    selected = None
    if da.ndim == 3:
        if time_name is None or time_name not in da.dims:
            raise ValueError("Could not uniquely detect the time dimension; use --time-name.")
        size = da.sizes[time_name]
        index = time_index if time_index >= 0 else size + time_index
        if index < 0 or index >= size:
            raise IndexError(f"--time-index {time_index} is outside the available range 0..{size - 1}.")
        selected_value = ds[time_name].values[index]
        selected = {"dimension": time_name, "index": int(index), "value": str(selected_value)}
        da = da.isel({time_name: index})
    da = da.transpose(lat_name, lon_name)
    lat = np.asarray(ds[lat_name].values, dtype=float)
    lon = np.asarray(ds[lon_name].values, dtype=float)
    if lat.ndim != 1 or lon.ndim != 1:
        raise ValueError("Only rectilinear 1-D latitude and longitude coordinates are supported.")
    values = np.asarray(da.values, dtype=float)
    unit = str(da.attrs.get("units", ""))
    ds.close()
    return lat, lon, values, candidates[0], unit, selected


def load_csv(path, variable, lat_name, lon_name):
    import pandas as pd

    df = pd.read_csv(path, sep=None, engine="python")
    names = set(df.columns)
    lat_name = choose_name(names, lat_name, LAT_NAMES, "lat")
    lon_name = choose_name(names, lon_name, LON_NAMES, "lon")
    numeric = [c for c in df.select_dtypes(include="number").columns if c not in (lat_name, lon_name)]
    if variable:
        if variable not in df.columns:
            raise ValueError(f"Variable {variable!r} not found; choices: {sorted(df.columns)}")
        numeric = [variable]
    if len(numeric) != 1:
        raise ValueError(f"Could not uniquely select a value column; choices: {numeric}. Use --variable.")
    if df.duplicated([lat_name, lon_name]).any():
        raise ValueError("Duplicate latitude-longitude rows found; aggregate them explicitly first.")
    table = df.pivot(index=lat_name, columns=lon_name, values=numeric[0]).sort_index().sort_index(axis=1)
    return table.index.to_numpy(float), table.columns.to_numpy(float), table.to_numpy(float), numeric[0], "", None


def load_tiff(path):
    try:
        import rasterio
    except ImportError as exc:
        raise RuntimeError("GeoTIFF input requires rasterio. Install it in the active Python environment.") from exc
    with rasterio.open(path) as src:
        if src.count != 1:
            raise ValueError(f"GeoTIFF has {src.count} bands; select or export one band first.")
        if src.crs is None or not src.crs.is_geographic:
            raise ValueError("GeoTIFF must have a geographic longitude-latitude CRS.")
        if not math.isclose(src.transform.b, 0.0) or not math.isclose(src.transform.d, 0.0):
            raise ValueError("Rotated GeoTIFF grids are not supported.")
        values = src.read(1, masked=True).filled(np.nan).astype(float)
        cols = np.arange(src.width)
        rows = np.arange(src.height)
        lon = src.transform.c + (cols + 0.5) * src.transform.a
        lat = src.transform.f + (rows + 0.5) * src.transform.e
        return lat, lon, values, src.descriptions[0] or "band_1", "", None


def load_data(args):
    suffix = args.input.suffix.lower()
    if suffix in (".nc", ".nc4", ".cdf"):
        result = load_netcdf(args.input, args.variable, args.lat_name, args.lon_name, args.time_name, args.time_index)
    elif suffix == ".csv":
        result = load_csv(args.input, args.variable, args.lat_name, args.lon_name)
    elif suffix in (".tif", ".tiff"):
        result = load_tiff(args.input)
    else:
        raise ValueError("Supported inputs are NetCDF (.nc/.nc4), GeoTIFF (.tif/.tiff), and CSV (.csv).")
    lat, lon, values, variable, detected_unit, selected = result
    if values.shape != (len(lat), len(lon)):
        raise ValueError(f"Data shape {values.shape} does not match latitude/longitude lengths {(len(lat), len(lon))}.")
    lat_order = np.argsort(lat)
    lon_normalized = ((lon + 180.0) % 360.0) - 180.0
    lon_order = np.argsort(lon_normalized)
    return lat[lat_order], lon_normalized[lon_order], values[np.ix_(lat_order, lon_order)], variable, detected_unit, selected


def mask_to_land(lat, lon, values):
    import cartopy.io.shapereader as shpreader
    import shapely

    land_path = shpreader.natural_earth(resolution="110m", category="physical", name="land")
    geometries = list(shpreader.Reader(land_path).geometries())
    land = shapely.union_all(geometries)
    xx, yy = np.meshgrid(lon, lat)
    keep = shapely.intersects_xy(land, xx, yy)
    return np.where(keep, values, np.nan), int(np.count_nonzero(keep))


def subset_lat(lat, values, low, high):
    low = np.nanmin(lat) if low is None else low
    high = np.nanmax(lat) if high is None else high
    if low >= high:
        raise ValueError("--lat-min must be smaller than --lat-max.")
    keep = (lat >= low) & (lat <= high)
    if not np.any(keep):
        raise ValueError("Latitude crop contains no data.")
    return lat[keep], values[keep], float(low), float(high)


def profile(values, method, confidence, percentiles):
    from scipy.stats import t

    count = np.sum(np.isfinite(values), axis=1)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        mean = np.nanmean(values, axis=1)
    lower = np.full(mean.shape, np.nan)
    upper = np.full(mean.shape, np.nan)
    if method == "none":
        return mean, lower, upper, count
    if method == "sd":
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            sd = np.nanstd(values, axis=1, ddof=1)
        lower, upper = mean - sd, mean + sd
    elif method == "percentile":
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            lower, upper = np.nanpercentile(values, percentiles, axis=1)
    else:
        if not 0.0 < confidence < 1.0:
            raise ValueError("--confidence must be between 0 and 1.")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            sd = np.nanstd(values, axis=1, ddof=1)
        critical = t.ppf((1.0 + confidence) / 2.0, np.maximum(count - 1, 1))
        half = critical * sd / np.sqrt(np.maximum(count, 1))
        lower, upper = mean - half, mean + half
    lower[count < 2] = np.nan
    upper[count < 2] = np.nan
    return mean, lower, upper, count


def color_settings(values, args):
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        raise ValueError("No finite values remain after loading and latitude cropping.")
    vmin = float(np.nanpercentile(finite, 2)) if args.vmin is None else args.vmin
    vmax = float(np.nanpercentile(finite, 98)) if args.vmax is None else args.vmax
    crosses = vmin < args.center < vmax
    if crosses and args.vmin is None and args.vmax is None:
        radius = max(abs(vmin - args.center), abs(vmax - args.center))
        vmin, vmax = args.center - radius, args.center + radius
    if not vmin < vmax:
        vmin, vmax = float(np.nanmin(finite)), float(np.nanmax(finite))
    if not vmin < vmax:
        vmin, vmax = vmin - 0.5, vmax + 0.5
    cmap = args.cmap or ("RdBu_r" if crosses else "viridis")
    return vmin, vmax, cmap, crosses


def uncertainty_label(args):
    if args.uncertainty == "ci":
        return f"Zonal mean ({args.confidence:.0%} CI)"
    if args.uncertainty == "sd":
        return "Zonal mean ± s.d."
    if args.uncertainty == "percentile":
        return f"Zonal mean ({args.percentiles[0]:g}–{args.percentiles[1]:g}th pct.)"
    return "Zonal mean"


def draw(args, lat, lon, values, variable, unit):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    from matplotlib.colors import TwoSlopeNorm
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes

    mean, lower, upper, count = profile(values, args.uncertainty, args.confidence, args.percentiles)
    vmin, vmax, cmap, crosses = color_settings(values, args)
    projection = ccrs.Robinson() if args.projection == "robinson" else ccrs.PlateCarree()
    fig = plt.figure(figsize=(10.8, 5.2), constrained_layout=False)
    grid = fig.add_gridspec(1, 2, width_ratios=(4.6, 0.88), left=0.045, right=0.955, bottom=0.12, top=0.90, wspace=0.13)
    ax = fig.add_subplot(grid[0, 0], projection=projection)
    norm = TwoSlopeNorm(vmin=vmin, vcenter=args.center, vmax=vmax) if crosses else None
    mesh = ax.pcolormesh(lon, lat, values, transform=ccrs.PlateCarree(), shading="auto", cmap=cmap,
                         norm=norm, vmin=None if norm else vmin, vmax=None if norm else vmax, rasterized=True)
    ax.set_extent([-180, 180, args.display_lat_min, args.display_lat_max], crs=ccrs.PlateCarree())
    if not args.no_boundaries:
        ax.add_feature(cfeature.LAND, facecolor="none", edgecolor="0.15", linewidth=0.55, zorder=3)
        ax.add_feature(cfeature.COASTLINE, linewidth=0.55, zorder=4)
        ax.add_feature(cfeature.BORDERS, linewidth=0.3, edgecolor="0.35", zorder=4)
    ax.gridlines(draw_labels=False, linewidth=0.45, color="0.65", alpha=0.55, linestyle="--")
    ax.set_title(args.title, fontsize=13, pad=10)
    cax = inset_axes(ax, width="100%", height="100%", loc="lower left",
                     bbox_to_anchor=(0.59, 0.182, 0.27, 0.040), bbox_transform=ax.transAxes, borderpad=0)
    cb = fig.colorbar(mesh, cax=cax, orientation="horizontal", extend="both")
    cb.set_label(unit or variable, fontsize=9, labelpad=2)
    cb.ax.tick_params(labelsize=8, length=2)

    pax = fig.add_subplot(grid[0, 1])
    if args.uncertainty != "none":
        pax.fill_betweenx(lat, lower, upper, color="0.82", alpha=0.75, linewidth=0)
    pax.plot(mean, lat, color="0.12", linewidth=1.25)
    if np.nanmin(mean) < 0 < np.nanmax(mean) or crosses:
        pax.axvline(0, color="0.45", linestyle="--", linewidth=0.9)
    pax.set_ylim(args.display_lat_min, args.display_lat_max)
    pax.yaxis.tick_right()
    pax.yaxis.set_label_position("right")
    pax.set_ylabel("Latitude (°)")
    pax.set_xlabel(uncertainty_label(args))
    pax.grid(True, color="0.82", linestyle=":", linewidth=0.7)
    pax.spines[:].set_color("0.25")
    # Cartopy shrinks projected axes inside their GridSpec cell to preserve the
    # map aspect ratio. Align the profile to that final, visible map frame.
    fig.canvas.draw()
    map_box = ax.get_position()
    profile_box = pax.get_position()
    pax.set_position([profile_box.x0, map_box.y0, profile_box.width, map_box.height])
    output = args.output or args.input.with_name(args.input.stem + "_map_zonal.png")
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=args.dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output, mean, lower, upper, count, vmin, vmax, cmap


def main():
    args = parser().parse_args()
    lat, lon, values, variable, detected_unit, selected = load_data(args)
    lat, values, args.lat_min_resolved, args.lat_max_resolved = subset_lat(lat, values, args.lat_min, args.lat_max)
    land_grid_cells = None
    if args.land_only:
        values, land_grid_cells = mask_to_land(lat, lon, values)
    looks_global = args.lat_min is None and args.lat_max is None and lat.min() <= -89.0 and lat.max() >= 89.0
    use_global = args.map_domain == "global" or (args.map_domain == "auto" and looks_global)
    args.display_lat_min = -90.0 if use_global else args.lat_min_resolved
    args.display_lat_max = 90.0 if use_global else args.lat_max_resolved
    unit = args.unit or detected_unit
    output, mean, lower, upper, count, vmin, vmax, cmap = draw(args, lat, lon, values, variable, unit)
    stats = {
        "input": str(args.input.resolve()), "output": str(output.resolve()), "variable": variable, "unit": unit,
        "shape": list(values.shape), "latitude_range": [float(lat.min()), float(lat.max())],
        "longitude_range": [float(lon.min()), float(lon.max())], "finite_cells": int(np.isfinite(values).sum()),
        "data_range": [float(np.nanmin(values)), float(np.nanmax(values))], "color_range": [vmin, vmax], "cmap": cmap,
        "selected_slice": selected, "land_only": args.land_only, "land_grid_cells": land_grid_cells,
        "projection": args.projection, "map_domain": "global" if use_global else "data",
        "display_latitude_range": [args.display_lat_min, args.display_lat_max], "uncertainty": args.uncertainty,
        "confidence": args.confidence if args.uncertainty == "ci" else None,
        "percentiles": list(args.percentiles) if args.uncertainty == "percentile" else None,
        "zonal_finite_count_min_max": [int(count.min()), int(count.max())],
        "zonal_mean_range": [float(np.nanmin(mean)), float(np.nanmax(mean))], "dpi": args.dpi,
        "note": "CI treats finite longitude cells as samples; spatial autocorrelation may reduce effective sample size."
    }
    stats_path = output.with_suffix(".stats.json")
    stats_path.write_text(json.dumps(stats, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(output)
    print(stats_path)


if __name__ == "__main__":
    main()
