---
name: plot-global-zonal-profile
description: Read a global or hemispheric two-dimensional longitude-latitude field, or select one time slice from a three-dimensional NetCDF variable, and create a publication-ready paired figure with a map on the left, an inset horizontal colorbar, and a zonal-mean profile with uncertainty shading on the right. Use for NetCDF, GeoTIFF, or long-form CSV inputs; .nc/.nc4/.tif/.tiff/.csv files; global maps, hemispheric maps, land-only masks, first-time-step maps, zonal means, latitude profiles, confidence intervals, standard-deviation bands, or percentile bands.
---

# Plot Global Zonal Profile

Create the figure with `scripts/plot_global_zonal_profile.py`.

## Workflow

1. Inspect the input and identify the plotted variable, latitude, longitude, title, unit, and desired uncertainty definition.
2. Run the script. Omit variable and coordinate overrides only when detection is unambiguous.
3. Inspect the PNG and sibling `*.stats.json`. Check projection, color limits, colorbar placement, missing-value mask, profile label, and latitude coverage.
4. Return both files and explicitly state how the uncertainty band was calculated.

## Command

```bash
python scripts/plot_global_zonal_profile.py INPUT \
  --variable VARIABLE \
  --title "Spatial pattern and zonal profile" \
  --unit "unit" \
  --uncertainty ci --confidence 0.95 \
  --output OUTPUT.png
```

Useful options:

- `--uncertainty ci`: Student-t interval for the longitude-sample mean at each latitude; default.
- `--uncertainty sd`: mean ± one longitude-sample standard deviation, matching figures labeled “± s.d.”.
- `--uncertainty percentile --percentiles 2.5 97.5`: empirical longitude percentiles.
- `--uncertainty none`: draw only the zonal mean.
- `--cmap`, `--vmin`, `--vmax`, and `--center`: control colors. If data cross zero, use a symmetric diverging scale by default.
- `--projection robinson|platecarree`: use Robinson for global data and Plate Carrée when a rectangular hemispheric panel is preferred.
- `--map-domain auto|global|data`: show −90° to 90° for a true global field and the retained latitude range for hemispheric data. `auto` detects global coverage from coordinates; use `global` to force full-pole display.
- `--lat-min` and `--lat-max`: crop the map and profile consistently.
- `--lat-name`, `--lon-name`, and `--variable`: resolve ambiguous NetCDF or CSV fields.
- `--time-index 0`: select one time step from a 3-D NetCDF variable. Never select a time implicitly; record the selected coordinate in the stats file.
- `--land-only`: retain only grid-cell centers inside Natural Earth land polygons. Apply the same mask before calculating the zonal mean and uncertainty.
- `--dpi 300`: retain publication resolution unless the user asks otherwise.

## Input rules

- For NetCDF, require a two-dimensional variable on one-dimensional latitude and longitude coordinates, or use `--time-index` to select one slice from a variable with exactly one time dimension. Squeeze singleton dimensions; reject every other unresolved non-spatial dimension instead of silently averaging it.
- For CSV, require long-form rows with latitude, longitude, and one numeric value column. Reject duplicate latitude-longitude rows. Use overrides when several value columns exist.
- For GeoTIFF, require a geographic longitude-latitude CRS and a single band. Require `rasterio`; reject projected and rotated rasters rather than treating pixel indices as coordinates.
- Normalize longitude order, sort latitude south-to-north, convert fill values to missing values, and preserve missing cells.

## Statistical rules

- Compute the zonal mean independently at every latitude from finite longitude cells.
- Treat `ci` as an interval over available longitude samples: mean ± t critical value × sample standard error. Require at least two finite cells; record sample counts in the stats file.
- Do not imply that longitude cells are statistically independent. Spatial autocorrelation can make the default t interval too narrow. If inferential coverage is important, ask the user for a block-bootstrap or effective-sample-size method.
- Distinguish confidence intervals from standard-deviation envelopes in the caption and axis label.
- Do not apply cosine-latitude weights within a zonal mean because cells at a fixed latitude have the same area factor on a regular longitude grid.

## Figure contract

- Place the map on the left and the narrow latitude profile on the right. Align the profile's top and bottom edges exactly with the map's visible projection frame; do not let the profile span the full canvas height.
- Place a short horizontal colorbar low in the lower-right portion of the map panel. Keep it below Australia and other important mapped regions.
- Plot latitude on the profile's vertical axis, use the same latitude limits as the map, draw the zonal mean as a dark line, and draw uncertainty as a light-gray band.
- Add coastlines, borders, and light graticules. Use a dashed zero-reference line when zero is relevant.
- Cartopy may download Natural Earth boundaries on first use. If an offline diagnostic run is necessary, use the hidden `--no-boundaries` switch and do not present that diagnostic image as the final publication figure.
- Save a tightly cropped PNG plus `*.stats.json` containing detected fields, range, zonal sample counts, uncertainty definition, confidence level, and plotting settings.
