# 科研数据下载缓存与校验（pooch）

按文件清单管理科研数据下载与缓存，通过哈希校验确认文件完整性和版本。

原始 skill 目录：`pooch/`。核心入口为 `SKILL.md`；随附脚本和参考资料保留原始目录结构。

源码：https://github.com/SteadfastAsArt/geoscience-skills/tree/c1eb8e67c67ab714d0599461058e4a350d95cb1d/pooch

版本：`c1eb8e67c67ab714d0599461058e4a350d95cb1d`。

将 `pooch/` 作为独立 skill 目录使用。运行所需 Python 库及外部程序见 `SKILL.md`，需在使用环境中另行安装。

原始文件内容未修改。本压缩包额外附带本说明和上游许可证；不包含本地运行环境、缓存或个人数据。
