# xrd-annotation

Annotate OriginLab-generated SVG XRD (X-ray Diffraction) figures with characteristic peak markers, dashed vertical guide lines, and a mineral-phase legend.

## Features

- Parses PDF card stick-pattern peak data from SVG `<polyline>` elements
- Selects characteristic peaks automatically (main phase: 5 peaks, others: 1–3)
- Draws dashed vertical lines from peak markers to PDF card sticks
- Places distinct shape symbols (● ▲ ■ ◆ ★) at marker positions
- Generates a text-only legend in the chart upper-right
- Supports single and multi-PDF-card stacked plots
- Preserves all original SVG elements (axes, fonts, line widths)

## Requirements

- Python 3.8+
- `beautifulsoup4`
- `lxml`

```bash
pip install beautifulsoup4 lxml
```

## Usage

```bash
python3 scripts/annotate.py
```

On first run, you'll be prompted for the input and output directories. The configuration is saved to `~/.config/xrd-annotation/config.json` and reused on subsequent runs. Delete the config file to reset.

### SVG Requirements

Input SVGs must contain:
- PDF card stick patterns as `<polyline>` elements with `olab:data` attributes
- Layer-structured `olab:scope` attributes (e.g., `Layer1.Plot0`)
- PDF card names as `<text>` elements containing "PDF"
- XRD curve data in `Layer0.Plot*` polylines

## Symbol Assignment

Symbols (shape + colour) are automatically assigned from pools — no predefined mineral list needed:

| Pool | Values |
|------|--------|
| Shapes | circle, triangle, square, diamond, star |
| Colours | red, blue, green, purple, orange, teal, pink, brown, blue-grey, olive |

Supports any number of mineral phases. Shapes cycle when more than 5 phases exist.

## Customisation

Edit the top of `scripts/annotate.py` to change:
- `_SHAPE_POOL` — available shapes
- `_COLOUR_POOL` — available colours

## License

[MIT](LICENSE)
