---
name: xrd-annotation
description: Annotate XRD diffraction pattern SVG files with characteristic peak markers, dashed vertical guide lines, and a mineral-phase legend. Handles both multi-PDF-card stacked plots and single-PDF-card patterns. Preserves all original SVG elements (axes, line widths, fonts, positions). Use when the user needs to label XRD peaks, annotate diffraction patterns, or mark mineral phase reference peaks on powder XRD figures.
triggers:
  - XRD
  - xrd
  - diffraction
  - 衍射
  - peak annotation
  - 标注特征峰
  - PDF card
  - 矿物相
  - mineral phase
  - powder diffraction
  - 粉末衍射
---

# XRD Peak Annotation

Annotate OriginLab-generated SVG XRD figures with characteristic peak markers, dashed vertical guide lines, and a mineral-phase legend.

## When to Use

- The user has XRD diffraction pattern SVG files (typically from OriginLab with `olab:` namespaced polyline data)
- They want to mark characteristic peaks for mineral phases identified by PDF cards
- The SVGs may be single or multi-layer stacked plots

## What It Does

1. Parses PDF card stick-pattern peak data from the SVG's `polyline` elements
2. Selects characteristic peaks: main mineral phase gets 5 peaks, others 1–3
3. Draws dashed vertical lines from each peak marker down to the matching PDF stick
4. Places shape symbols (● ▲ ■ ◆ ★ etc.) at the marker position near the topmost XRD curve
5. Adds a text-only legend (symbol + mineral name) in the chart upper-right, arranged in 2 rows for multi-card files

## Requirements

The SVG files must contain:
- PDF card stick patterns as `<polyline>` elements with `olab:data` attributes
- Layer-structured `olab:scope` attributes (e.g., `Layer1.Plot0`)
- PDF card names as `<text>` elements containing "PDF"
- XRD curve data in `Layer0.Plot*` polylines (for marker y-positioning)

## Usage

```
python3 scripts/annotate.py
```

**首次运行**会询问输入和输出目录，配置保存至 `~/.config/xrd-annotation/config.json`，后续运行直接读取。

如需重置路径，删除该配置文件即可。

## Symbol Assignment

符号（形状 + 颜色）按矿物相出现顺序从预设池中自动分配，无需预先定义：

| 池 | 可用值 |
|---|---|
| Shapes | circle, triangle, square, diamond, star |
| Colours | red, blue, green, purple, orange, teal, pink, brown, blue-grey, olive |

支持任意数量的矿物相，超过 5 种时形状会循环使用，颜色按序递增。

## Adding New Shapes or Colours

Edit the `_SHAPE_POOL` and `_COLOUR_POOL` lists at the top of `scripts/annotate.py`.
