#!/usr/bin/env python3
"""
Annotate XRD SVG files with:
- Characteristic peak markers using distinct shape symbols per mineral phase
- Dashed vertical lines from peak marker to PDF card stick positions
- Legend (symbol + mineral name) in chart upper-right, 2-row grid layout
- Full preservation of all original elements

Configuration is stored at ~/.config/xrd-annotation/config.json
"""

import json
import re
import math
import sys
from pathlib import Path
from bs4 import BeautifulSoup

# ── Shape & colour pools (cycled through for any mineral phase) ─────────────
_SHAPE_POOL = ['circle', 'triangle', 'square', 'diamond', 'star']
_COLOUR_POOL = [
    '#D32F2F',  # red
    '#1976D2',  # blue
    '#388E3C',  # green
    '#7B1FA2',  # purple
    '#E65100',  # orange
    '#00838F',  # teal
    '#AD1457',  # pink
    '#4E342E',  # brown
    '#37474F',  # blue-grey
    '#827717',  # olive
]

CONFIG_PATH = Path.home() / '.config' / 'xrd-annotation' / 'config.json'


# ── Config helpers ──────────────────────────────────────────────────────────

def load_config():
    """Load saved config or return empty dict."""
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save_config(cfg):
    """Persist config to disk."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False),
                           encoding='utf-8')


def resolve_paths():
    """Return (input_dir, output_dir) — ask user on first run."""
    cfg = load_config()

    # ── Input directory ──
    if 'input_dir' in cfg and Path(cfg['input_dir']).is_dir():
        xrd_dir = Path(cfg['input_dir'])
    else:
        default_in = str(Path.home() / 'Documents' / 'XRD')
        print(f'输入 SVG 所在目录 [{default_in}]: ', end='', flush=True)
        raw = input().strip()
        xrd_dir = Path(raw) if raw else Path(default_in)
        if not xrd_dir.is_dir():
            print(f'  ✗ 目录不存在: {xrd_dir}')
            sys.exit(1)
        cfg['input_dir'] = str(xrd_dir)

    # ── Output directory ──
    if 'output_dir' in cfg and Path(cfg['output_dir']).is_dir():
        out_dir = Path(cfg['output_dir'])
    else:
        default_out = str(xrd_dir / 'annotated')
        print(f'标注结果保存目录 [{default_out}]: ', end='', flush=True)
        raw = input().strip()
        out_dir = Path(raw) if raw else Path(default_out)
        cfg['output_dir'] = str(out_dir)

    save_config(cfg)
    out_dir.mkdir(parents=True, exist_ok=True)
    return xrd_dir, out_dir


# ── Dynamic symbol assignment ───────────────────────────────────────────────

def build_symbol_map(mineral_names):
    """
    Given a list of unique mineral phase names, return a dict mapping each
    name to {'shape': ..., 'colour': ..., 'size': ..., 'label': ...}.
    Shapes and colours are cycled from the pools so every phase is distinct.
    """
    sym_map = {}
    for i, name in enumerate(mineral_names):
        sym_map[name] = {
            'shape':  _SHAPE_POOL[i % len(_SHAPE_POOL)],
            'colour': _COLOUR_POOL[i % len(_COLOUR_POOL)],
            'size':   85,
            'label':  name,
        }
    return sym_map


# ── Peak parsing ────────────────────────────────────────────────────────────

def parse_svg(svg_path):
    """Extract chart information and peak data from an SVG file."""
    with open(svg_path, 'r', encoding='utf-8') as fh:
        content = fh.read()

    soup = BeautifulSoup(content, 'lxml-xml')

    svg_list = soup.find_all('svg')
    inner = svg_list[1] if len(svg_list) >= 2 else svg_list[0]
    vb = inner.get('viewBox', '0,0 6378.97,5197.94')
    vb_parts = [float(x) for x in re.split(r'[,\s]+', vb) if x]
    vb_w, vb_h = vb_parts[2], vb_parts[3]

    chart_top = float('inf')
    chart_bottom = float('-inf')
    for path in soup.find_all('path'):
        d = path.get('d', '')
        if not d:
            continue
        nums = re.findall(r'[\d.]+', d)
        if len(nums) < 4:
            continue
        ys = [float(nums[i]) for i in range(1, len(nums), 2)]
        if ys:
            chart_top = min(chart_top, min(ys))
            chart_bottom = max(chart_bottom, max(ys))

    pdf_cards = []
    for text in soup.find_all('text'):
        txt = text.get_text().strip()
        if 'PDF' in txt:
            pdf_cards.append(txt)

    peaks_by_layer = {}
    for pl in soup.find_all('polyline'):
        olab = pl.get('olab:data')
        if not olab:
            continue
        scope = pl.get('olab:scope', '')
        try:
            data = json.loads(olab)
            m = re.match(r'Layer(\d+)\.Plot(\d+)', scope)
            if m:
                layer = int(m.group(1))
                if layer not in peaks_by_layer:
                    peaks_by_layer[layer] = []
                peaks_by_layer[layer].append({
                    'x': float(data.get('X', 0)),
                    'y': float(data.get('Y', 0)),
                    'points': pl.get('points', ''),
                })
        except (json.JSONDecodeError, ValueError):
            continue

    curve_index = _build_curve_index(soup)

    return {
        'soup': soup,
        'inner_svg': inner,
        'vb_w': vb_w,
        'vb_h': vb_h,
        'chart_top': chart_top,
        'chart_bottom': chart_bottom,
        'pdf_cards': pdf_cards,
        'peaks_by_layer': peaks_by_layer,
        'curve_index': curve_index,
    }


def _build_curve_index(soup):
    """Collect Layer0 plot data so we can later look up y at a given x."""
    plots = {}
    for pl in soup.find_all('polyline'):
        scope = pl.get('olab:scope', '')
        if not scope.startswith('Layer0.Plot'):
            continue
        m = re.match(r'Layer0\.Plot(\d+)', scope)
        if not m:
            continue
        pn = int(m.group(1))
        if pn not in plots:
            plots[pn] = []
        for pt in pl.get('points', '').split():
            coords = pt.split(',')
            if len(coords) == 2:
                plots[pn].append((float(coords[0]), float(coords[1])))

    if not plots:
        return None

    topmost = min(plots.keys(),
                  key=lambda p: sum(y for _, y in plots[p]) / max(1, len(plots[p])))
    points = sorted(plots[topmost], key=lambda p: p[0])
    return {'points': points, 'topmost_plot': topmost}


def curve_y_at_x(curve_index, target_x):
    """Return the y-value of the topmost XRD curve at 2θ = target_x."""
    if curve_index is None:
        return None
    pts = curve_index['points']
    for i in range(len(pts) - 1):
        x1, y1 = pts[i]
        x2, y2 = pts[i + 1]
        if min(x1, x2) <= target_x <= max(x1, x2):
            if abs(x2 - x1) < 0.001:
                return y1
            t = (target_x - x1) / (x2 - x1)
            return y1 + t * (y2 - y1)
    return None


# ── Peak selection ──────────────────────────────────────────────────────────

def select_peaks(pdf_cards, peaks_by_layer):
    """Select characteristic peaks to annotate."""
    minerals = []
    for layer in sorted(peaks_by_layer):
        if layer == 0:
            continue
        peaks = peaks_by_layer[layer]
        if not peaks:
            continue
        card_name = (pdf_cards[layer - 1]
                     if layer - 1 < len(pdf_cards)
                     else f'Layer{layer}')
        # Derive short name from card: take text before '-PDF' or ':PDF'
        short = card_name.split('-PDF')[0].split(':')[0].strip()
        sorted_peaks = sorted(peaks, key=lambda p: p['y'], reverse=True)
        strong = len([p for p in peaks if p['y'] > 50])
        minerals.append({
            'layer': layer, 'name': card_name, 'short': short,
            'strong': strong, 'sorted': sorted_peaks,
        })

    minerals.sort(key=lambda m: (m['strong'],
                                  m['sorted'][0]['y'] if m['sorted'] else 0),
                  reverse=True)

    selected = []
    for i, m in enumerate(minerals):
        if i == 0:
            n = 5
        else:
            n = 3 if m['strong'] >= 3 else (2 if m['strong'] >= 2 else 1)

        for peak in m['sorted'][:n]:
            selected.append({
                'x': peak['x'], 'y': peak['y'], 'points': peak['points'],
                'mineral': m['short'], 'layer': m['layer'],
            })

    return selected


# ── SVG element builders ────────────────────────────────────────────────────

def _tag(soup, name, text=None, **attrs):
    """Create a BeautifulSoup Tag with attrs and optional text content."""
    t = soup.new_tag(name)
    for k, v in attrs.items():
        t[k] = v
    if text is not None:
        t.string = text
    return t


def symbol_element(soup, shape, cx, cy, colour, size):
    """Build a BeautifulSoup Tag for one shape symbol."""
    half = size / 2.0
    sw = 15

    if shape == 'circle':
        return _tag(soup, 'circle', cx=str(cx), cy=str(cy),
                     r=str(half), fill='none', stroke=colour,
                     **{'stroke-width': str(sw)})

    if shape == 'triangle':
        h = size * 0.866
        pts = (f'{cx:.1f},{cy - h * 0.55:.1f} '
               f'{cx - half:.1f},{cy + h * 0.45:.1f} '
               f'{cx + half:.1f},{cy + h * 0.45:.1f}')
        return _tag(soup, 'polygon', points=pts, fill='none',
                     stroke=colour, **{'stroke-width': str(sw)})

    if shape == 'square':
        return _tag(soup, 'rect', x=str(cx - half), y=str(cy - half),
                     width=str(size), height=str(size), fill='none',
                     stroke=colour, **{'stroke-width': str(sw)})

    if shape == 'diamond':
        pts = (f'{cx:.1f},{cy - half:.1f} '
               f'{cx + half:.1f},{cy:.1f} '
               f'{cx:.1f},{cy + half:.1f} '
               f'{cx - half:.1f},{cy:.1f}')
        return _tag(soup, 'polygon', points=pts, fill='none',
                     stroke=colour, **{'stroke-width': str(sw)})

    if shape == 'star':
        outer = half
        inner = half * 0.382
        pts = []
        for i in range(10):
            angle = math.radians(i * 36 - 90)
            r = outer if i % 2 == 0 else inner
            pts.append(f'{cx + r * math.cos(angle):.1f},'
                       f'{cy + r * math.sin(angle):.1f}')
        return _tag(soup, 'polygon', points=' '.join(pts), fill='none',
                     stroke=colour, **{'stroke-width': str(sw)})

    return None


# ── Legend builder ──────────────────────────────────────────────────────────

def build_legend(soup, minerals, sym_map, x, y):
    """2-row legend: shape symbol + space + mineral name, generous spacing."""
    g = soup.new_tag('g', **{'class': 'peak-legend'})

    n = len(minerals)
    row_h = 250
    item_w = 560

    if n <= 1:
        m = minerals[0]
        sym = sym_map.get(m)
        sy = y + 50
        el = symbol_element(soup, sym['shape'], x + 50, sy,
                             sym['colour'], sym['size'] * 0.65)
        if el is not None:
            g.append(el)
        g.append(_tag(soup, 'text', x=str(x + 130), y=str(sy + 20),
                       text=sym['label'],
                       **{'text-anchor': 'start',
                          'font-family': "Times New Roman,'MS PGothic',SimSun",
                          'font-size': '150', 'fill': sym['colour'],
                          'font-weight': '700'}))
    else:
        row1 = minerals[:3]
        row2 = minerals[3:]
        for row_idx, row_items in enumerate([row1, row2]):
            row_y = y + row_idx * row_h
            for col, m in enumerate(row_items):
                sym = sym_map.get(m)
                ix = x + col * item_w
                iy = row_y + 50

                el = symbol_element(soup, sym['shape'], ix + 50, iy,
                                     sym['colour'], sym['size'] * 0.6)
                if el is not None:
                    g.append(el)

                g.append(_tag(soup, 'text', x=str(ix + 130), y=str(iy + 20),
                               text=sym['label'],
                               **{'text-anchor': 'start',
                                  'font-family': "Times New Roman,'MS PGothic',SimSun",
                                  'font-size': '150', 'fill': sym['colour'],
                                  'font-weight': '700'}))

    return g


# ── Main annotator ──────────────────────────────────────────────────────────

def annotate(svg_path, out_path):
    """Add peak annotations to an SVG file and write the result."""
    info = parse_svg(svg_path)
    soup = info['soup']
    inner = info['inner_svg']
    chart_top = info['chart_top']
    curve_index = info['curve_index']

    selected = select_peaks(info['pdf_cards'], info['peaks_by_layer'])
    if not selected:
        print(f"  ⚠ No peaks selected — skipping")
        return

    # Collect unique mineral names in order of appearance
    seen = set()
    minerals = []
    for p in selected:
        if p['mineral'] not in seen:
            seen.add(p['mineral'])
            minerals.append(p['mineral'])

    # Build dynamic symbol map for these minerals
    sym_map = build_symbol_map(minerals)

    g_ann = soup.new_tag('g', **{'class': 'peak-annotations'})

    # ── Annotate each peak ──
    for peak in selected:
        pts = peak['points'].split()
        if len(pts) < 2:
            continue

        x_vals = []
        y_vals = []
        for pt in pts:
            coords = pt.split(',')
            if len(coords) == 2:
                x_vals.append(float(coords[0]))
                y_vals.append(float(coords[1]))
        if not x_vals:
            continue

        px = sum(x_vals) / len(x_vals)
        stick_top = min(y_vals)
        stick_bot = max(y_vals)

        sym = sym_map[peak['mineral']]

        # ── Determine marker y from topmost XRD curve position ──
        curve_y = curve_y_at_x(curve_index, px)
        if curve_y is None:
            curve_y = chart_top + 60
        mrk_y = curve_y - 130

        # ── Dashed vertical line from marker to stick bottom ──
        g_ann.append(_tag(soup, 'line',
                           x1=str(px), y1=str(mrk_y),
                           x2=str(px), y2=str(stick_bot),
                           stroke=sym['colour'],
                           **{'stroke-width': '9',
                              'stroke-dasharray': '110,70',
                              'opacity': '0.55'}))

        # ── Shape symbol at marker position ──
        el = symbol_element(soup, sym['shape'], px, mrk_y,
                             sym['colour'], sym['size'])
        if el is not None:
            g_ann.append(el)

        # ── Accent tick at the PDF stick ──
        g_ann.append(_tag(soup, 'line',
                           x1=str(px - 22), y1=str(stick_top),
                           x2=str(px + 22), y2=str(stick_top),
                           stroke=sym['colour'],
                           **{'stroke-width': '10', 'opacity': '0.8'}))

    # ── Legend ──
    legend_y = info['chart_top'] + 180
    legend_x = 3900 if len(minerals) > 1 else 4400
    g_ann.append(build_legend(soup, minerals, sym_map, legend_x, legend_y))

    inner.append(g_ann)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as fh:
        fh.write(str(soup))

    print(f"  ✓ {svg_path.name}  →  {out_path.name}")
    print(f"    Minerals: {', '.join(minerals)}")
    print(f"    Peaks: {len(selected)}  |  Chart top Y={chart_top:.0f}")


# ── Entry point ─────────────────────────────────────────────────────────────

def main():
    xrd_dir, out_dir = resolve_paths()

    svg_files = sorted(xrd_dir.glob('*.svg'))
    svg_files = [f for f in svg_files if f.name != 'Thumbs.db']

    if not svg_files:
        print(f'  ✗ 未在 {xrd_dir} 中找到 SVG 文件')
        sys.exit(1)

    print('=' * 70)
    print('XRD SVG ANNOTATION')
    print('=' * 70)
    print(f'  Input:  {xrd_dir}')
    print(f'  Output: {out_dir}')
    print()

    for f in svg_files:
        annotate(f, out_dir / f.name)

    print()
    print(f'Done — {len(svg_files)} files written to {out_dir}/')


if __name__ == '__main__':
    main()
