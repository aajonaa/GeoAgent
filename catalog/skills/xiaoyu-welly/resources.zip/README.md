# 测井曲线质量控制与重采样（welly）

读取和整理井曲线，执行曲线质量检查、尖峰处理、归一化及深度重采样。

原始 skill 目录：`welly/`。核心入口为 `SKILL.md`；随附脚本和参考资料保留原始目录结构。

源码：https://github.com/SteadfastAsArt/geoscience-skills/tree/c1eb8e67c67ab714d0599461058e4a350d95cb1d/welly

版本：`c1eb8e67c67ab714d0599461058e4a350d95cb1d`。

将 `welly/` 作为独立 skill 目录使用。运行所需 Python 库及外部程序见 `SKILL.md`，需在使用环境中另行安装。

原始文件内容未修改。本压缩包额外附带本说明和上游许可证；不包含本地运行环境、缓存或个人数据。
